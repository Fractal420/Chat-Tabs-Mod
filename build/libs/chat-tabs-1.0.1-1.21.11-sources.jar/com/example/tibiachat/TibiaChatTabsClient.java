package com.example.tibiachat;

import com.example.tibiachat.chat.ChatManager;
import com.example.tibiachat.config.TibiaChatConfig;
import com.example.tibiachat.gui.TibiaChatConfigScreen;
import com.example.tibiachat.hud.HudLayout;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_9779;
import org.lwjgl.glfw.GLFW;

public final class TibiaChatTabsClient implements ClientModInitializer {
    public static final String MOD_ID = "tibia_chat_tabs";
    public static final TibiaChatConfig CONFIG = TibiaChatConfig.load();
    public static final ChatManager CHAT = new ChatManager();

    private static final class_304.class_11900 CHAT_TABS_CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "key_category"));

    private static class_304 openSettingsKey;

    @Override
    public void onInitializeClient() {
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.chat_tabs.open_settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN,
                CHAT_TABS_CATEGORY
        ));

        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, timestamp) -> {
            String key = CHAT.classifyAndStore(message, sender, timestamp);
            return key != null && key.equals(CHAT.selectedKey());
        });

        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (overlay) {
                return true;
            }

            String key = CHAT.classifyAndStore(message, null, java.time.Instant.now());
            return key != null && key.equals(CHAT.selectedKey());
        });

        ClientSendMessageEvents.COMMAND.register(CHAT::onOutgoingCommand);

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> CONFIG.save());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            CHAT.tick();

            while (openSettingsKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new TibiaChatConfigScreen(null));
                }
            }
        });

        HudRenderCallback.EVENT.register(this::renderUnreadBadge);
    }

    private void renderUnreadBadge(class_332 ctx, class_9779 tickCounter) {
        int unread = CHAT.totalUnread();

        if (unread <= 0) {
            return;
        }

        class_310 mc = class_310.method_1551();
        String label = "\u2709 " + unread;
        int textWidth = mc.field_1772.method_1727(label);

        int x = HudLayout.notifIconX();
        int y = HudLayout.notifIconY(mc.method_22683().method_4502());
        float scale = HudLayout.notifIconScale();

        ctx.method_51448().pushMatrix();
        ctx.method_51448().translate(x, y);
        ctx.method_51448().scale(scale, scale);

        ctx.method_25294(-3, -2, textWidth + 3, 10, 0x90000000);
        ctx.method_27535(mc.field_1772, class_2561.method_43470(label), 0, 0, 0xFFFFD24A);

        ctx.method_51448().popMatrix();
    }
}