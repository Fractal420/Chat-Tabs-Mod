package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import com.example.tibiachat.hud.HudLayout;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HudEditScreen extends class_437 {

    private enum Target { NONE, TAB_BAR, TAB_BAR_RESIZE, ICON }

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;
    private Target dragging = Target.NONE;

    public HudEditScreen(class_437 parent) {
        super(class_2561.method_43470("Reposition Chat Tabs HUD"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 28, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x80000000);

        int barLeft = HudLayout.tabBarLeft();
        int barRight = HudLayout.tabBarRight(this.field_22789);
        int barTop = HudLayout.tabBarTop(this.field_22790);
        int barBottom = HudLayout.tabBarBottom(this.field_22790);

        context.method_25294(barLeft, barTop, barRight, barBottom, 0xB03A6EA5);
        context.method_25294(barRight - 6, barTop, barRight, barBottom, 0xFF4A90E2);

        context.method_27534(this.field_22793,
                class_2561.method_43470("TAB BAR"),
                barLeft + (barRight - barLeft) / 2, barTop + (barBottom - barTop) / 2 - 4, 0xFFFFFFFF);

        String sample = "\u2709 3";
        int textW = this.field_22793.method_1727(sample);
        int iconX = HudLayout.notifIconX();
        int iconY = HudLayout.notifIconY(this.field_22790);
        int iconW = HudLayout.notifIconWidth(textW);
        int iconH = HudLayout.notifIconHeight();

        context.method_25294(iconX - 3, iconY - 2, iconX + iconW, iconY + iconH, 0xB0C77A2A);
        context.method_27535(this.field_22793, class_2561.method_43470(sample), iconX, iconY, 0xFFFFD24A);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Drag elements to move anywhere. Drag tab bar right edge to resize length."),
                this.field_22789 / 2, 12, 0xFFFFFFFF);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private boolean withinResizeHandle(double x, double y) {
        int top = HudLayout.tabBarTop(this.field_22790);
        int bottom = HudLayout.tabBarBottom(this.field_22790);
        int right = HudLayout.tabBarRight(this.field_22789);
        return x >= right - 8 && x <= right + 8 && y >= top && y < bottom;
    }

    private boolean withinTabBar(double x, double y) {
        int top = HudLayout.tabBarTop(this.field_22790);
        int bottom = HudLayout.tabBarBottom(this.field_22790);
        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(this.field_22789);
        return x >= left && x < right && y >= top && y < bottom;
    }

    private boolean withinIcon(double x, double y) {
        String sample = "\u2709 3";
        int textW = this.field_22793.method_1727(sample);
        int iconX = HudLayout.notifIconX();
        int iconY = HudLayout.notifIconY(this.field_22790);
        int iconW = HudLayout.notifIconWidth(textW);
        int iconH = HudLayout.notifIconHeight();
        return x >= iconX - 3 && x < iconX + iconW && y >= iconY - 2 && y < iconY + iconH;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        if (withinIcon(click.comp_4798(), click.comp_4799())) {
            dragging = Target.ICON;
            return true;
        }
        if (withinResizeHandle(click.comp_4798(), click.comp_4799())) {
            dragging = Target.TAB_BAR_RESIZE;
            return true;
        }
        if (withinTabBar(click.comp_4798(), click.comp_4799())) {
            dragging = Target.TAB_BAR;
            return true;
        }
        dragging = Target.NONE;
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        switch (dragging) {
            case TAB_BAR -> {
                config.setTabBarOffsetX(Math.round(config.tabBarOffsetX() + (float) offsetX));
                config.setTabBarOffsetY(Math.round(config.tabBarOffsetY() + (float) offsetY));
                return true;
            }
            case TAB_BAR_RESIZE -> {
                config.setTabBarWidth(Math.max(50, Math.round(config.tabBarWidth() + (float) offsetX)));
                return true;
            }
            case ICON -> {
                config.setNotifIconOffsetX(Math.round(config.notifIconOffsetX() + (float) offsetX));
                config.setNotifIconOffsetY(Math.round(config.notifIconOffsetY() + (float) offsetY));
                return true;
            }
            default -> {
                return super.method_25403(click, offsetX, offsetY);
            }
        }
    }

    @Override
    public boolean method_25406(class_11909 click) {
        boolean wasDragging = dragging != Target.NONE;
        dragging = Target.NONE;
        if (wasDragging) {
            config.save();
            return true;
        }
        return super.method_25406(click);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}