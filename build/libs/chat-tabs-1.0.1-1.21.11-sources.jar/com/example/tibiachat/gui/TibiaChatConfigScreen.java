package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TibiaChatConfigScreen extends class_437 {

    private static final int ROW_HEIGHT = 24;
    private static final int SLIDER_WIDTH = 200;
    private static final int FIELD_WIDTH = 50;
    private static final int FIELD_GAP = 6;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;

    public TibiaChatConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Chat Tabs Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int y = 40;

        y = addSliderRow(centerX, y, "Tab bar size", TibiaChatConfig.MIN_BAR_SCALE, TibiaChatConfig.MAX_BAR_SCALE,
                config.tabBarScale(), false, "%.2fx",
                v -> config.setTabBarScale((float) v));

        y = addSliderRow(centerX, y, "Notification icon size", TibiaChatConfig.MIN_ICON_SCALE, TibiaChatConfig.MAX_ICON_SCALE,
                config.notifIconScale(), false, "%.2fx",
                v -> config.setNotifIconScale((float) v));

        y += 8;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reposition / Resize HUD"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new HudEditScreen(this));
                            }
                        })
                .method_46434(centerX - SLIDER_WIDTH / 2 - FIELD_GAP - FIELD_WIDTH / 2, y, SLIDER_WIDTH + FIELD_GAP + FIELD_WIDTH, 20)
                .method_46431());
        y += ROW_HEIGHT + 12;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset to Defaults"), btn -> {
                    config.resetHudDefaults();
                    config.save();
                    this.method_41843();
                })
                .method_46434(centerX - 100, y, 200, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(centerX - 100, this.field_22790 - 28, 200, 20)
                .method_46431());
    }

    private int addSliderRow(int centerX, int y, String label, double min, double max, double initial,
                              boolean wholeNumber, String format, DoubleConsumer apply) {
        int sliderX = centerX - (SLIDER_WIDTH + FIELD_GAP + FIELD_WIDTH) / 2;
        int fieldX = sliderX + SLIDER_WIDTH + FIELD_GAP;

        ValueSlider slider = new ValueSlider(sliderX, y, SLIDER_WIDTH, 20, min, max, initial, wholeNumber,
                v -> class_2561.method_43470(label + ": " + String.format(Locale.ROOT, format, v)),
                v -> {
                    apply.accept(v);
                    config.save();
                });

        class_342 field = new class_342(this.field_22793, fieldX, y, FIELD_WIDTH, 20, class_2561.method_43470(label));
        field.method_1852(String.format(Locale.ROOT, wholeNumber ? "%.0f" : "%.2f", initial));
        field.method_1863(text -> {
            try {
                double parsed = Double.parseDouble(text.trim());
                double clamped = Math.max(min, Math.min(max, parsed));
                slider.setRealValueSilently(clamped);
                apply.accept(clamped);
                config.save();
            } catch (NumberFormatException ignored) {
            }
        });

        this.method_37063(slider);
        this.method_37063(field);
        return y + ROW_HEIGHT;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}