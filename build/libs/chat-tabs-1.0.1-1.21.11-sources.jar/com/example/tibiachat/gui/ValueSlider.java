package com.example.tibiachat.gui;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import net.minecraft.class_2561;
import net.minecraft.class_357;

/**
 * A vanilla slider paired with an optional manual-entry text field elsewhere
 * on the screen. Dragging the slider calls {@link #onChange}; the owning
 * screen can also push a value in from a text field via
 * {@link #setRealValueSilently(double)} without re-triggering the callback.
 */
public class ValueSlider extends class_357 {
    private final double min;
    private final double max;
    private final boolean wholeNumber;
    private final DoubleFunction<class_2561> messageFactory;
    private final DoubleConsumer onChange;

    public ValueSlider(int x, int y, int width, int height, double min, double max,
                        double initialValue, boolean wholeNumber,
                        DoubleFunction<class_2561> messageFactory, DoubleConsumer onChange) {
        super(x, y, width, height, class_2561.method_43473(), normalize(initialValue, min, max));
        this.min = min;
        this.max = max;
        this.wholeNumber = wholeNumber;
        this.messageFactory = messageFactory;
        this.onChange = onChange;
        method_25346();
    }

    private static double normalize(double v, double min, double max) {
        if (max <= min) return 0.0;
        return Math.max(0.0, Math.min(1.0, (v - min) / (max - min)));
    }

    public double getRealValue() {
        double v = min + (max - min) * this.field_22753;
        return wholeNumber ? Math.round(v) : v;
    }

    /** Pushes a value in from an external source (e.g. the manual text field) without re-firing onChange. */
    public void setRealValueSilently(double v) {
        this.field_22753 = normalize(v, min, max);
        method_25346();
    }

    @Override
    protected void method_25346() {
        method_25355(messageFactory.apply(getRealValue()));
    }

    @Override
    protected void method_25344() {
        onChange.accept(getRealValue());
    }
}
