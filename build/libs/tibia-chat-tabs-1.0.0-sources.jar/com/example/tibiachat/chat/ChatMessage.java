package com.example.tibiachat.chat;

import java.time.Instant;
import java.util.UUID;
import net.minecraft.class_2561;

public record ChatMessage(
    class_2561 component,
    MessageType type,
    String speakerName,
    UUID speakerUuid,
    String conversationKey,
    Instant receivedAt,
    String fingerprint
) {}
