package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.*;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_5481;

public final class TibiaChatScreen extends class_408 {
    private class_342 input;

    private int panelLeft;
    private int panelTop;
    private int panelRight;
    private int panelBottom;
    private int contentTop;
    private int inputY;

    private static final int TAB_H = 22;
    private static final int INPUT_H = 20;
    private static final int LINE_H = 10;
    private static final int PAD = 6;

    public TibiaChatScreen(String initialText) {
        super(initialText, false);
    }

    @Override
    protected void method_25426() {
        /*
         * IMPORTANT:
         * ChatScreen initializes its internal chatField here.
         * Its removed() method later expects that field to be non-null.
         */
        super.method_25426();

        /*
         * Remove the vanilla widget(s) from the screen because we are
         * rendering/positioning our own input field.
         */
        method_37067();

        panelLeft = Math.max(8, field_22789 / 2 - 260);
        panelRight = Math.min(field_22789 - 8, field_22789 / 2 + 260);
        panelTop = Math.max(8, field_22790 / 2 - 150);
        panelBottom = Math.min(field_22790 - 8, field_22790 / 2 + 150);

        contentTop = panelTop + TAB_H + 4;
        inputY = panelBottom - INPUT_H - 6;

        input = new class_342(
                field_22793,
                panelLeft + 6,
                inputY,
                panelRight - panelLeft - 12,
                INPUT_H,
                class_2561.method_43470("")
        );

        input.method_1880(256);

        input.method_47404(getInputPlaceholder());

        /*
         * Keep ChatScreen's internal reference pointing at our actual
         * input widget. This is the important part for lifecycle methods
         * such as removed(), history handling, and other inherited code.
         */
        this.field_2382 = input;

        method_37063(input);
        method_48265(input);
    }

    private class_2561 getInputPlaceholder() {
        return class_2561.method_43470(
                TibiaChatTabsClient.CHAT.selectedKey().equals(ConversationManager.MAIN)
                        ? "Type message..."
                        : "Message..."
        );
    }

    @Override
    public void method_25394(
            class_332 ctx,
            int mouseX,
            int mouseY,
            float delta
    ) {
        method_25420(ctx, mouseX, mouseY, delta);

        ctx.method_25294(
                panelLeft,
                panelTop,
                panelRight,
                panelBottom,
                0xD0101010
        );

        ctx.method_25294(
                panelLeft,
                panelTop,
                panelRight,
                panelTop + TAB_H,
                0xE0202020
        );

        renderTabs(ctx, mouseX, mouseY);

        ctx.method_44379(
                panelLeft + 2,
                contentTop,
                panelRight - 2,
                inputY - 4
        );

        renderMessages(ctx);

        ctx.method_44380();

        ctx.method_25294(
                panelLeft,
                inputY - 4,
                panelRight,
                inputY - 3,
                0xFF404040
        );

        if (input != null) {
            input.method_25394(ctx, mouseX, mouseY, delta);
        }

        renderTooltip(ctx, mouseX, mouseY);
    }

    private void renderTabs(
            class_332 ctx,
            int mx,
            int my
    ) {
        int x = panelLeft + 2;

        drawTab(
                ctx,
                "Main",
                ConversationManager.MAIN,
                x,
                78,
                mx,
                my
        );

        x += 78;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = Math.max(
                    74,
                    Math.min(
                            150,
                            field_22793.method_1727(c.playerName()) + 28
                    )
            );

            drawTab(
                    ctx,
                    c.playerName(),
                    c.key(),
                    x,
                    w,
                    mx,
                    my
            );

            x += w;

            if (x > panelRight - 30) {
                break;
            }
        }
    }

    private void drawTab(
            class_332 ctx,
            String label,
            String key,
            int x,
            int ignored,
            int mx,
            int my
    ) {
        int w = Math.max(
                74,
                Math.min(
                        150,
                        field_22793.method_1727(label) + 28
                )
        );

        boolean selected =
                TibiaChatTabsClient.CHAT.selectedKey().equals(key);

        boolean hover =
                mx >= x &&
                mx < x + w &&
                my >= panelTop &&
                my < panelTop + TAB_H;

        ctx.method_25294(
                x,
                panelTop,
                x + w,
                panelTop + TAB_H,
                selected
                        ? 0xFF3A3A3A
                        : (hover ? 0xFF303030 : 0xFF252525)
        );

        String shown = label;

        if (field_22793.method_1727(shown) > w - 25) {
            shown =
                    field_22793.method_27523(shown, w - 31) + "…";
        }

        if (!key.equals(ConversationManager.MAIN)) {
            Conversation c =
                    TibiaChatTabsClient.CHAT.conversations().getByKey(key);

            if (c != null && c.unread() > 0) {
                shown += " •" + c.unread();
            }
        }

        ctx.method_27535(
                field_22793,
                class_2561.method_43470(shown),
                x + 7,
                panelTop + 7,
                0xFFFFFFFF
        );
    }

    private void renderMessages(class_332 ctx) {
        List<ChatMessage> msgs =
                TibiaChatTabsClient.CHAT.selectedMessages();

        int maxLines = Math.max(
                1,
                (inputY - contentTop - 4) / LINE_H
        );

        List<class_5481> lines = new ArrayList<>();

        for (ChatMessage m : msgs) {
            lines.addAll(
                    field_22793.method_1728(
                            m.component(),
                            panelRight - panelLeft - 2 * PAD
                    )
            );
        }

        int maxScroll = Math.max(
                0,
                lines.size() - maxLines
        );

        int scroll = 0;

        Conversation c =
                TibiaChatTabsClient.CHAT.selectedConversation();

        if (c != null) {
            scroll = Math.min(c.scroll(), maxScroll);
        }

        int start = Math.max(
                0,
                lines.size() - maxLines - scroll
        );

        int y = inputY - LINE_H;

        for (
                int i = start;
                i < lines.size() && y >= contentTop;
                i++, y -= LINE_H
        ) {
            ctx.method_35720(
                    field_22793,
                    lines.get(i),
                    panelLeft + PAD,
                    y,
                    0xFFFFFFFF
            );
        }
    }

    private void renderTooltip(
            class_332 ctx,
            int mx,
            int my
    ) {
        if (
                my < panelTop ||
                my > panelTop + TAB_H
        ) {
            return;
        }

        int x = panelLeft + 2;

        for (Conversation c :
                TibiaChatTabsClient.CHAT.conversations().all()) {

            int w = Math.max(
                    74,
                    Math.min(
                            150,
                            field_22793.method_1727(c.playerName()) + 28
                    )
            );

            if (
                    mx >= x &&
                    mx < x + w &&
                    field_22793.method_1727(c.playerName()) > w - 25
            ) {
                ctx.method_51434(
                        field_22793,
                        List.of(class_2561.method_43470(c.playerName())),
                        mx,
                        my
                );

                return;
            }

            x += w;
        }
    }

    @Override
    public boolean method_25402(
            class_11909 click,
            boolean doubled
    ) {
        double mx = click.comp_4798();
        double my = click.comp_4799();

        if (
                click.method_74245() == GLFW.GLFW_MOUSE_BUTTON_LEFT &&
                my >= panelTop &&
                my < panelTop + TAB_H
        ) {
            int x = panelLeft + 2;

            if (mx >= x && mx < x + 78) {
                TibiaChatTabsClient.CHAT.select(
                        ConversationManager.MAIN
                );

                syncInput();
                return true;
            }

            x += 78;

            for (Conversation c :
                    TibiaChatTabsClient.CHAT.conversations().all()) {

                int w = Math.max(
                        74,
                        Math.min(
                                150,
                                field_22793.method_1727(c.playerName()) + 28
                        )
                );

                if (mx >= x && mx < x + w) {
                    TibiaChatTabsClient.CHAT.select(c.key());

                    syncInput();
                    return true;
                }

                x += w;
            }
        }

        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(
            double mouseX,
            double mouseY,
            double horizontalAmount,
            double verticalAmount
    ) {
        Conversation c =
                TibiaChatTabsClient.CHAT.selectedConversation();

        if (c != null) {
            c.scrollBy(
                    (int) Math.signum(-verticalAmount)
            );

            return true;
        }

        return true;
    }

    @Override
    public boolean method_25404(
            net.minecraft.class_11908 inputEvent
    ) {
        if (
                inputEvent.comp_4795() == GLFW.GLFW_KEY_ENTER ||
                inputEvent.comp_4795() == GLFW.GLFW_KEY_KP_ENTER
        ) {
            String text = input.method_1882().trim();

            if (!text.isEmpty()) {
                send(text);
            }

            input.method_1852("");
            return true;
        }

        return super.method_25404(inputEvent);
    }

    private void send(String text) {
        class_310 mc =
                class_310.method_1551();

        if (mc.field_1724 == null) {
            return;
        }

        if (
                ConversationManager.MAIN.equals(
                        TibiaChatTabsClient.CHAT.selectedKey()
                )
        ) {
            if (text.startsWith("/")) {
                mc.field_1724.field_3944.method_45730(
                        text.substring(1)
                );
            } else {
                mc.field_1724.field_3944.method_45729(
                        text
                );
            }

            return;
        }

        Conversation c =
                TibiaChatTabsClient.CHAT.selectedConversation();

        if (c == null) {
            return;
        }

        String cmd =
                TibiaChatTabsClient.CONFIG.whisperCommand();

        String body =
                cmd + " " + c.playerName() + " " + text;

        String command =
                body.startsWith("/")
                        ? body.substring(1)
                        : body;

        mc.field_1724.field_3944.method_45730(
                command
        );
    }

    private void syncInput() {
        if (input == null) {
            return;
        }

        input.method_47404(getInputPlaceholder());
        input.method_1852("");
        input.method_25365(true);
        method_48265(input);
    }

    @Override
    public void method_25419() {
        super.method_25419();
    }
}
