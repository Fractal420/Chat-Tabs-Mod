package com.example.tibiachat.mixin;

import com.example.tibiachat.gui.TibiaChatScreen;
import net.minecraft.class_310;
import net.minecraft.class_408;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class ChatHudSetScreenMixin {

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void tibiaChatTabs$open(class_437 screen, CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;

        // Only intercept the vanilla chat screen being opened directly.
        // Exact class check (not instanceof) is required because
        // TibiaChatScreen itself extends ChatScreen - instanceof would
        // cause this injection to trigger again on our own screen and recurse.
        if (screen == null || screen.getClass() != class_408.class) return;
        if (client.field_1724 == null) return;

        ci.cancel();
        client.method_1507(new TibiaChatScreen(""));
    }
}
