package com.example.tibiachat.mixin;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.gui.TibiaChatScreen;
import net.minecraft.class_310;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public abstract class ChatHudSetScreenMixin {
    @Inject(method="setScreen", at=@At("HEAD"), cancellable=true)
    private void tibiaChatTabs$open(CallbackInfo ci){
        class_310 client=class_310.method_1551();
        if(client.field_1724==null || client.field_1755 instanceof TibiaChatScreen) return;
        ci.cancel();
        client.method_1507(new TibiaChatScreen(""));
    }
}
