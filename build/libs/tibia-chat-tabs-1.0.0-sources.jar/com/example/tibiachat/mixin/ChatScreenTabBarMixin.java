package com.example.tibiachat.mixin;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.Conversation;
import com.example.tibiachat.chat.ConversationManager;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public abstract class ChatScreenTabBarMixin {

    @Shadow
    protected class_342 chatField;

    private static final int TAB_H = 16;
    private static final int TAB_W_MAIN = 50;
    private static final int TAB_W_MIN = 60;
    private static final int TAB_W_MAX = 120;
    private static final int TAB_SCROLL_STEP = 40;

    private int tibiaChatTabs$tabScroll = 0;

    @Inject(method = "render", at = @At("TAIL"))
    private void tibiaChatTabs$drawTabs(
            class_332 ctx,
            int mouseX,
            int mouseY,
            float delta,
            CallbackInfo ci
    ) {
        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int top = screenH - 14 - TAB_H - 2;
        int bottom = top + TAB_H;

        ctx.method_25294(0, top, screenW, bottom, 0xB0101010);

        int x = 2;

        x = tibiaChatTabs$drawTab(
                ctx,
                mc,
                "Main",
                ConversationManager.MAIN,
                x,
                TAB_W_MAIN,
                top,
                bottom,
                mouseX,
                mouseY,
                0
        );

        int tabsLeft = x;
        int tabsRight = screenW - 4;

        tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);

        int tabX = tabsLeft - tibiaChatTabs$tabScroll;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = tibiaChatTabs$tabWidth(mc, c.playerName());

            if (tabX + w <= tabsLeft) {
                tabX += w;
                continue;
            }

            if (tabX >= tabsRight) {
                break;
            }

            tibiaChatTabs$drawTab(
                    ctx,
                    mc,
                    c.playerName(),
                    c.key(),
                    tabX,
                    w,
                    top,
                    bottom,
                    mouseX,
                    mouseY,
                    c.unread()
            );

            tabX += w;
        }

        int maxScroll = tibiaChatTabs$maxTabScroll(mc, tabsLeft, tabsRight);

        if (tibiaChatTabs$tabScroll > 0) {
            ctx.method_25294(tabsLeft, top, tabsLeft + 8, bottom, 0xCC101010);
            ctx.method_27535(
                    mc.field_1772,
                    class_2561.method_43470("‹"),
                    tabsLeft + 1,
                    top + 3,
                    0xFFFFFFFF
            );
        }

        if (tibiaChatTabs$tabScroll < maxScroll) {
            ctx.method_25294(tabsRight - 8, top, tabsRight, bottom, 0xCC101010);
            ctx.method_27535(
                    mc.field_1772,
                    class_2561.method_43470("›"),
                    tabsRight - 6,
                    top + 3,
                    0xFFFFFFFF
            );
        }
    }

    private int tibiaChatTabs$tabWidth(class_310 mc, String label) {
        return Math.max(
                TAB_W_MIN,
                Math.min(
                        TAB_W_MAX,
                        mc.field_1772.method_1727(label) + 24
                )
        );
    }

    private int tibiaChatTabs$totalTabsWidth(class_310 mc) {
        int width = 0;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            width += tibiaChatTabs$tabWidth(mc, c.playerName());
        }

        return width;
    }

    private int tibiaChatTabs$maxTabScroll(
            class_310 mc,
            int tabsLeft,
            int tabsRight
    ) {
        int availableWidth = Math.max(0, tabsRight - tabsLeft);
        int totalWidth = tibiaChatTabs$totalTabsWidth(mc);

        return Math.max(0, totalWidth - availableWidth);
    }

    private void tibiaChatTabs$clampTabScroll(
            class_310 mc,
            int tabsLeft,
            int tabsRight
    ) {
        int maxScroll = tibiaChatTabs$maxTabScroll(
                mc,
                tabsLeft,
                tabsRight
        );

        if (tibiaChatTabs$tabScroll < 0) {
            tibiaChatTabs$tabScroll = 0;
        }

        if (tibiaChatTabs$tabScroll > maxScroll) {
            tibiaChatTabs$tabScroll = maxScroll;
        }
    }

    private int tibiaChatTabs$drawTab(
            class_332 ctx,
            class_310 mc,
            String label,
            String key,
            int x,
            int w,
            int top,
            int bottom,
            int mouseX,
            int mouseY,
            int unread
    ) {
        boolean selected = TibiaChatTabsClient.CHAT.selectedKey().equals(key);

        boolean hover =
                mouseX >= x &&
                mouseX < x + w &&
                mouseY >= top &&
                mouseY < bottom;

        ctx.method_25294(
                x,
                top,
                x + w - 1,
                bottom,
                selected
                        ? 0xFF3A3A3A
                        : (hover ? 0xFF303030 : 0xFF202020)
        );

        String shown = label;

        if (unread > 0) {
            shown = shown + " (" + unread + ")";
        }

        if (mc.field_1772.method_1727(shown) > w - 8) {
            shown =
                    mc.field_1772.method_27523(shown, w - 12)
                            + "…";
        }

        ctx.method_27535(
                mc.field_1772,
                class_2561.method_43470(shown),
                x + 5,
                top + 4,
                unread > 0
                        ? 0xFFFFD24A
                        : 0xFFFFFFFF
        );

        return x + w;
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), cancellable = true)
    private void tibiaChatTabs$onMouseScrolled(
            double mouseX,
            double mouseY,
            double horizontalAmount,
            double verticalAmount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int top = screenH - 14 - TAB_H - 2;
        int bottom = top + TAB_H;

        if (mouseY < top || mouseY >= bottom) {
            return;
        }

        int tabsLeft = 2 + TAB_W_MAIN;
        int tabsRight = screenW - 4;

        int maxScroll = tibiaChatTabs$maxTabScroll(
                mc,
                tabsLeft,
                tabsRight
        );

        if (maxScroll <= 0) {
            return;
        }

        double amount =
                Math.abs(horizontalAmount) > Math.abs(verticalAmount)
                        ? horizontalAmount
                        : verticalAmount;

        if (amount == 0) {
            return;
        }

        tibiaChatTabs$tabScroll -=
                (int) Math.round(amount * TAB_SCROLL_STEP);

        tibiaChatTabs$clampTabScroll(
                mc,
                tabsLeft,
                tabsRight
        );

        cir.setReturnValue(true);
    }

    @Inject(
            method = "mouseClicked",
            at = @At("HEAD"),
            cancellable = true
    )
    private void tibiaChatTabs$onClick(
            class_11909 click,
            boolean doubled,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return;
        }

        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int top = screenH - 14 - TAB_H - 2;
        int bottom = top + TAB_H;

        if (click.comp_4799() < top || click.comp_4799() >= bottom) {
            return;
        }

        int x = 2;

        if (
                click.comp_4798() >= x &&
                click.comp_4798() < x + TAB_W_MAIN
        ) {
            tibiaChatTabs$select(ConversationManager.MAIN);
            cir.setReturnValue(true);
            return;
        }

        int tabsLeft = x + TAB_W_MAIN;
        int tabsRight = screenW - 4;

        tibiaChatTabs$clampTabScroll(
                mc,
                tabsLeft,
                tabsRight
        );

        int tabX = tabsLeft - tibiaChatTabs$tabScroll;

        for (Conversation c :
                TibiaChatTabsClient.CHAT.conversations().all()) {

            int w =
                    tibiaChatTabs$tabWidth(
                            mc,
                            c.playerName()
                    );

            if (tabX + w <= tabsLeft) {
                tabX += w;
                continue;
            }

            if (tabX >= tabsRight) {
                break;
            }

            if (
                    click.comp_4798() >= tabX &&
                    click.comp_4798() < tabX + w
            ) {
                tibiaChatTabs$select(c.key());
                cir.setReturnValue(true);
                return;
            }

            tabX += w;
        }
    }

    private void tibiaChatTabs$select(String key) {
        TibiaChatTabsClient.CHAT.select(key);

        class_338 hud =
                class_310.method_1551()
                        .field_1705
                        .method_1743();

        hud.method_1808(false);

        for (
                var msg :
                TibiaChatTabsClient.CHAT.selectedMessages()
        ) {
            hud.method_1812(msg.component());
        }

        tibiaChatTabs$scrollSelectedIntoView();
    }

    private void tibiaChatTabs$scrollSelectedIntoView() {
        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();

        int tabsLeft = 2 + TAB_W_MAIN;
        int tabsRight = screenW - 4;

        String selectedKey =
                TibiaChatTabsClient.CHAT.selectedKey();

        if (ConversationManager.MAIN.equals(selectedKey)) {
            tibiaChatTabs$tabScroll = 0;
            return;
        }

        int tabX = tabsLeft;

        for (
                Conversation c :
                TibiaChatTabsClient.CHAT.conversations().all()
        ) {
            int w =
                    tibiaChatTabs$tabWidth(
                            mc,
                            c.playerName()
                    );

            if (c.key().equals(selectedKey)) {
                int visibleLeft =
                        tabX - tibiaChatTabs$tabScroll;

                int visibleRight =
                        visibleLeft + w;

                if (visibleLeft < tabsLeft) {
                    tibiaChatTabs$tabScroll -=
                            tabsLeft - visibleLeft;
                } else if (visibleRight > tabsRight) {
                    tibiaChatTabs$tabScroll +=
                            visibleRight - tabsRight;
                }

                tibiaChatTabs$clampTabScroll(
                        mc,
                        tabsLeft,
                        tabsRight
                );

                return;
            }

            tabX += w;
        }
    }

    @Inject(
            method = "keyPressed",
            at = @At("HEAD"),
            cancellable = true
    )
    private void tibiaChatTabs$onKey(
            class_11908 input,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (
                input.comp_4795() != GLFW.GLFW_KEY_ENTER &&
                input.comp_4795() != GLFW.GLFW_KEY_KP_ENTER
        ) {
            return;
        }

        String key =
                TibiaChatTabsClient.CHAT.selectedKey();

        if (ConversationManager.MAIN.equals(key)) {
            return;
        }

        Conversation c =
                TibiaChatTabsClient.CHAT.conversations()
                        .getByKey(key);

        if (c == null || chatField == null) {
            return;
        }

        String text =
                chatField.method_1882().trim();

        if (text.isEmpty()) {
            cir.setReturnValue(true);
            return;
        }

        class_310 mc =
                class_310.method_1551();

        if (mc.field_1724 == null) {
            return;
        }

        String whisperCmd =
                TibiaChatTabsClient.CONFIG.whisperCommand();

        String body =
                whisperCmd +
                " " +
                c.playerName() +
                " " +
                text;

        String command =
                body.startsWith("/")
                        ? body.substring(1)
                        : body;

        mc.field_1724.field_3944.method_45730(command);

        chatField.method_1852("");

        cir.setReturnValue(true);
    }
}