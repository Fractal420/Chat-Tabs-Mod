package com.example.tibiachat.mixin;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.Conversation;
import com.example.tibiachat.chat.ConversationManager;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_338;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Replaces the old "swap in a whole custom Screen" approach. Vanilla ChatScreen and
 * ChatHud do all the real work (rendering, scrollback, PgUp/PgDn history, text input,
 * compatibility with any other chat-formatting mod); we only draw a thin tab strip on
 * top and route clicks on it. The actual filtering of which messages are visible per
 * tab happens in TibiaChatTabsClient via ALLOW_CHAT/ALLOW_GAME, not here.
 */
@Mixin(class_408.class)
public abstract class ChatScreenTabBarMixin {

    private static final int TAB_H = 16;
    private static final int TAB_W_MAIN = 50;
    private static final int TAB_W_MIN = 60;
    private static final int TAB_W_MAX = 120;

    @Inject(method = "render", at = @At("TAIL"))
    private void tibiaChatTabs$drawTabs(class_332 ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        // Sits directly above where vanilla draws its input box (bottom ~14px of screen).
        int top = screenH - 14 - TAB_H - 2;
        int bottom = top + TAB_H;

        ctx.method_25294(0, top, screenW, bottom, 0xB0101010);

        int x = 2;
        x = tibiaChatTabs$drawTab(ctx, mc, "Main", ConversationManager.MAIN, x, TAB_W_MAIN, top, bottom, mouseX, mouseY, 0);

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = tibiaChatTabs$tabWidth(mc, c.playerName());
            if (x + w > screenW - 4) break; // ran out of room; extra tabs simply won't show
            x = tibiaChatTabs$drawTab(ctx, mc, c.playerName(), c.key(), x, w, top, bottom, mouseX, mouseY, c.unread());
        }
    }

    private int tibiaChatTabs$tabWidth(class_310 mc, String label) {
        return Math.max(TAB_W_MIN, Math.min(TAB_W_MAX, mc.field_1772.method_1727(label) + 24));
    }

    private int tibiaChatTabs$drawTab(class_332 ctx, class_310 mc, String label, String key,
                                       int x, int w, int top, int bottom, int mouseX, int mouseY, int unread) {
        boolean selected = TibiaChatTabsClient.CHAT.selectedKey().equals(key);
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= top && mouseY < bottom;

        ctx.method_25294(x, top, x + w - 1, bottom, selected ? 0xFF3A3A3A : (hover ? 0xFF303030 : 0xFF202020));

        String shown = label;
        if (unread > 0) shown = shown + " (" + unread + ")";
        if (mc.field_1772.method_1727(shown) > w - 8) {
            shown = mc.field_1772.method_27523(shown, w - 12) + "…";
        }
        ctx.method_27535(mc.field_1772, class_2561.method_43470(shown), x + 5, top + 4,
            unread > 0 ? 0xFFFFD24A : 0xFFFFFFFF);

        return x + w;
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void tibiaChatTabs$onClick(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) return;

        class_310 mc = class_310.method_1551();
        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();
        int top = screenH - 14 - TAB_H - 2;
        int bottom = top + TAB_H;

        if (click.comp_4799() < top || click.comp_4799() >= bottom) return;

        int x = 2;
        if (click.comp_4798() >= x && click.comp_4798() < x + TAB_W_MAIN) {
            tibiaChatTabs$select(ConversationManager.MAIN);
            cir.setReturnValue(true);
            return;
        }
        x += TAB_W_MAIN;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = tibiaChatTabs$tabWidth(mc, c.playerName());
            if (x + w > screenW - 4) break;
            if (click.comp_4798() >= x && click.comp_4798() < x + w) {
                tibiaChatTabs$select(c.key());
                cir.setReturnValue(true);
                return;
            }
            x += w;
        }
    }

    /** Selects a tab and repaints the vanilla ChatHud from stored history for that tab. */
    private void tibiaChatTabs$select(String key) {
        TibiaChatTabsClient.CHAT.select(key);
        class_338 hud = class_310.method_1551().field_1705.method_1743();
        hud.method_1808(false); // false = keep the up-arrow command history, just clear visible lines
        for (var msg : TibiaChatTabsClient.CHAT.selectedMessages()) {
            hud.method_1812(msg.component());
        }
    }
}
