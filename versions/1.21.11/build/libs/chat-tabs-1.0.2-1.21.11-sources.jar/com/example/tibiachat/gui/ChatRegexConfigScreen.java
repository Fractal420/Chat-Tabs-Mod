package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Lets people change the whisper command / aliases and the private-message
 * detection regexes from in-game, instead of hand-editing the config JSON.
 */
public class ChatRegexConfigScreen extends class_437 {

    private static final int ROW_HEIGHT = 22;
    private static final int TOP_Y = 40;
    private static final int LABEL_WIDTH = 130;
    private static final int REMOVE_SIZE = 20;
    private static final int BOTTOM_RESERVED = 90;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;

    private final List<String> workingRegexes = new ArrayList<>();
    private int scrollIndex = 0;

    private class_342 whisperCommandBox;
    private class_342 aliasesBox;
    private int listTop;
    private int listBottom;

    public ChatRegexConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Private Message Detection"));
        this.parent = parent;
        this.workingRegexes.addAll(config.incomingWhisperRegexes());
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int fieldWidth = 220;
        int y = TOP_Y;

        int cmdLabelX = centerX - (LABEL_WIDTH + fieldWidth) / 2;
        int cmdFieldX = cmdLabelX + LABEL_WIDTH;

        whisperCommandBox = new class_342(this.field_22793, cmdFieldX, y, fieldWidth, 20, class_2561.method_43470("Whisper command"));
        whisperCommandBox.method_1852(config.whisperCommand());
        whisperCommandBox.method_1863(text -> {
            if (!text.isBlank()) {
                config.setWhisperCommand(text.trim());
                config.save();
            }
        });
        this.method_37063(whisperCommandBox);
        y += ROW_HEIGHT + 6;

        aliasesBox = new class_342(this.field_22793, cmdFieldX, y, fieldWidth, 20, class_2561.method_43470("Aliases"));
        aliasesBox.method_1852(String.join(", ", config.whisperAliases()));
        aliasesBox.method_1863(text -> {
            List<String> aliases = List.of(text.split(","));
            config.setWhisperAliases(aliases);
            config.save();
        });
        this.method_37063(aliasesBox);
        y += ROW_HEIGHT + 14;

        listTop = y;
        listBottom = this.field_22790 - BOTTOM_RESERVED;

        int visibleRows = Math.max(1, (listBottom - listTop) / ROW_HEIGHT);
        int maxScroll = Math.max(0, workingRegexes.size() - visibleRows);
        scrollIndex = Math.max(0, Math.min(scrollIndex, maxScroll));

        int rowFieldWidth = 280;
        int rowX = centerX - (rowFieldWidth + REMOVE_SIZE + 6) / 2;
        int removeX = rowX + rowFieldWidth + 6;

        int rowY = listTop;
        int lastIndexShown = Math.min(workingRegexes.size(), scrollIndex + visibleRows);

        for (int i = scrollIndex; i < lastIndexShown; i++) {
            final int index = i;
            class_342 row = new class_342(this.field_22793, rowX, rowY, rowFieldWidth, 20,
                    class_2561.method_43470("Regex " + (index + 1)));
            row.method_1880(300);
            row.method_1852(workingRegexes.get(index));
            row.method_1863(text -> {
                if (index < workingRegexes.size()) {
                    workingRegexes.set(index, text);
                    applyRegexes();
                }
            });
            this.method_37063(row);

            this.method_37063(class_4185.method_46430(class_2561.method_43470("x"), btn -> {
                        if (index < workingRegexes.size()) {
                            workingRegexes.remove(index);
                            applyRegexes();
                            this.method_41843();
                        }
                    })
                    .method_46434(removeX, rowY, REMOVE_SIZE, 20)
                    .method_46431());

            rowY += ROW_HEIGHT;
        }

        int bottomY = this.field_22790 - BOTTOM_RESERVED + 12;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("+ Add Rule"), btn -> {
                    workingRegexes.add("");
                    applyRegexes();
                    scrollIndex = Math.max(0, workingRegexes.size() - visibleRows);
                    this.method_41843();
                })
                .method_46434(centerX - 160, bottomY, 150, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset to Defaults"), btn -> {
                    config.resetWhisperDetectionDefaults();
                    workingRegexes.clear();
                    workingRegexes.addAll(config.incomingWhisperRegexes());
                    whisperCommandBox.method_1852(config.whisperCommand());
                    aliasesBox.method_1852(String.join(", ", config.whisperAliases()));
                    scrollIndex = 0;
                    this.method_41843();
                })
                .method_46434(centerX + 10, bottomY, 150, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(centerX - 100, this.field_22790 - 28, 200, 20)
                .method_46431());
    }

    private void applyRegexes() {
        config.setIncomingWhisperRegexes(workingRegexes.stream()
                .filter(s -> !s.isBlank())
                .collect(Collectors.toList()));
        config.save();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseY >= listTop && mouseY < listBottom) {
            int visibleRows = Math.max(1, (listBottom - listTop) / ROW_HEIGHT);
            int maxScroll = Math.max(0, workingRegexes.size() - visibleRows);
            int newScroll = Math.max(0, Math.min(maxScroll, scrollIndex - (int) Math.signum(verticalAmount)));
            if (newScroll != scrollIndex) {
                scrollIndex = newScroll;
                this.method_41843();
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);

        int centerX = this.field_22789 / 2;
        int fieldWidth = 220;
        int labelX = centerX - (LABEL_WIDTH + fieldWidth) / 2;

        context.method_51433(this.field_22793, "Whisper command:", labelX, TOP_Y + 6, 0xFFFFFFFF, true);
        context.method_51433(this.field_22793, "Aliases (comma-sep):", labelX, TOP_Y + ROW_HEIGHT + 6 + 6, 0xFFFFFFFF, true);
        context.method_25300(this.field_22793, "Whisper detection regexes (scroll to see more):",
                centerX, listTop - 12, 0xFFFFFFFF);

        if (workingRegexes.isEmpty()) {
            context.method_25300(this.field_22793, "No rules yet - click + Add Rule", centerX, listTop + 4, 0xFFAAAAAA);
        }
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
