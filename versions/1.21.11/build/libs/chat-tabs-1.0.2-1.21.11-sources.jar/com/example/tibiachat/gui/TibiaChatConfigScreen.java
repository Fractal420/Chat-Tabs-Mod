package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import com.example.tibiachat.hud.HudLayout;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TibiaChatConfigScreen extends class_437 {

    private static final int ROW_HEIGHT = 22;
    private static final int SLIDER_WIDTH = 160;
    private static final int FIELD_WIDTH = 42;
    private static final int FIELD_GAP = 4;
    private static final int PREVIEW_HEIGHT = 28;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;

    public TibiaChatConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Chat Tabs Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int y = 36 + PREVIEW_HEIGHT + 8;

        y = addSliderRow(centerX, y, "Tab bar size", TibiaChatConfig.MIN_BAR_SCALE, TibiaChatConfig.MAX_BAR_SCALE,
                config.tabBarScale(), false, "%.2fx",
                v -> config.setTabBarScale((float) v));
        y = addSliderRow(centerX, y, "Notif icon size", TibiaChatConfig.MIN_ICON_SCALE, TibiaChatConfig.MAX_ICON_SCALE,
                config.notifIconScale(), false, "%.2fx",
                v -> config.setNotifIconScale((float) v));
        y += 4;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reposition / Resize HUD"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new HudEditScreen(this));
                            }
                        })
                .method_46434(centerX - 110, y, 220, 20)
                .method_46431());
        y += ROW_HEIGHT + 6;

        y = addSliderRow(centerX, y, "Tab bar opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabBarAlpha(), true, "%.0f",
                v -> config.setTabBarAlpha((int) v));
        y = addSliderRow(centerX, y, "Tab opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabAlpha(), true, "%.0f",
                v -> config.setTabAlpha((int) v));
        y += 4;

        y = addColorPickerRow(centerX, y, "Tab bar color", config.tabBarColor(),
                v -> config.setTabBarColor(v));
        y = addColorPickerRow(centerX, y, "Tab color", config.tabColor(),
                v -> config.setTabColor(v));
        y += 6;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Edit Detection Rules"),
                        btn -> {
                            if (this.field_22787 != null) {
                                this.field_22787.method_1507(new ChatRegexConfigScreen(this));
                            }
                        })
                .method_46434(centerX - 110, y, 220, 20)
                .method_46431());
        y += ROW_HEIGHT + 10;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset All Defaults"), btn -> {
                    config.resetHudDefaults();
                    config.resetAppearanceDefaults();
                    config.save();
                    this.method_41843();
                })
                .method_46434(centerX - 100, y, 200, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(centerX - 100, this.field_22790 - 28, 200, 20)
                .method_46431());
    }

    private int addSliderRow(int centerX, int y, String label, double min, double max, double initial,
                              boolean wholeNumber, String format, DoubleConsumer apply) {
        int totalW = SLIDER_WIDTH + FIELD_GAP + FIELD_WIDTH;
        int sliderX = centerX - totalW / 2;
        int fieldX = sliderX + SLIDER_WIDTH + FIELD_GAP;

        ValueSlider slider = new ValueSlider(sliderX, y, SLIDER_WIDTH, 18, min, max, initial, wholeNumber,
                v -> class_2561.method_43470(label + ": " + String.format(Locale.ROOT, format, v)),
                v -> {
                    apply.accept(v);
                    config.save();
                });

        class_342 field = new class_342(this.field_22793, fieldX, y, FIELD_WIDTH, 18, class_2561.method_43470(label));
        field.method_1852(String.format(Locale.ROOT, wholeNumber ? "%.0f" : "%.2f", initial));
        field.method_1863(text -> {
            try {
                double parsed = Double.parseDouble(text.trim());
                double clamped = Math.max(min, Math.min(max, parsed));
                slider.setRealValueSilently(clamped);
                apply.accept(clamped);
                config.save();
            } catch (NumberFormatException ignored) {
            }
        });

        this.method_37063(slider);
        this.method_37063(field);
        return y + ROW_HEIGHT;
    }

    private int addColorPickerRow(int centerX, int y, String label, int initialRgb, IntConsumer apply) {
        int r = (initialRgb >> 16) & 0xFF;
        int g = (initialRgb >> 8) & 0xFF;
        int b = initialRgb & 0xFF;

        int totalW = 280;
        int startX = centerX - totalW / 2;

        int sliderW = 70;
        int gap = 4;

        ValueSlider rSlider = new ValueSlider(startX, y, sliderW, 16, 0, 255, r, true,
                v -> class_2561.method_43470("R:" + (int) v),
                v -> {
                    int cur = label.contains("bar") ? config.tabBarColor() : config.tabColor();
                    int nr = (int) v;
                    int ng = (cur >> 8) & 0xFF;
                    int nb = cur & 0xFF;
                    apply.accept((nr << 16) | (ng << 8) | nb);
                    config.save();
                });
        this.method_37063(rSlider);

        ValueSlider gSlider = new ValueSlider(startX + sliderW + gap, y, sliderW, 16, 0, 255, g, true,
                v -> class_2561.method_43470("G:" + (int) v),
                v -> {
                    int cur = label.contains("bar") ? config.tabBarColor() : config.tabColor();
                    int nr = (cur >> 16) & 0xFF;
                    int ng = (int) v;
                    int nb = cur & 0xFF;
                    apply.accept((nr << 16) | (ng << 8) | nb);
                    config.save();
                });
        this.method_37063(gSlider);

        ValueSlider bSlider = new ValueSlider(startX + 2 * (sliderW + gap), y, sliderW, 16, 0, 255, b, true,
                v -> class_2561.method_43470("B:" + (int) v),
                v -> {
                    int cur = label.contains("bar") ? config.tabBarColor() : config.tabColor();
                    int nr = (cur >> 16) & 0xFF;
                    int ng = (cur >> 8) & 0xFF;
                    int nb = (int) v;
                    apply.accept((nr << 16) | (ng << 8) | nb);
                    config.save();
                });
        this.method_37063(bSlider);

        class_342 hex = new class_342(this.field_22793, startX + 3 * (sliderW + gap), y, 52, 16, class_2561.method_43470("hex"));
        hex.method_1880(7);
        hex.method_1852(String.format(Locale.ROOT, "%06X", initialRgb));
        hex.method_1863(text -> {
            String h = text.trim();
            if (h.startsWith("#")) h = h.substring(1);
            if (!h.matches("[0-9a-fA-F]{6}")) return;
            try {
                int parsed = Integer.parseInt(h, 16);
                apply.accept(parsed);
                config.save();
            } catch (NumberFormatException ignored) {
            }
        });
        this.method_37063(hex);

        return y + ROW_HEIGHT;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);

        int previewTop = 24;
        int previewLeft = this.field_22789 / 2 - 160;
        int previewRight = this.field_22789 / 2 + 160;
        int barH = PREVIEW_HEIGHT - 4;

        int barAlpha = config.tabBarAlpha();
        int barRgb = config.tabBarColor();
        context.method_25294(previewLeft, previewTop, previewRight, previewTop + barH, (barAlpha << 24) | barRgb);

        int tabAlpha = config.tabAlpha();
        int tabRgb = config.tabColor();
        int tabW = 70;
        context.method_25294(previewLeft + 4, previewTop + 3, previewLeft + 4 + tabW, previewTop + barH - 3, (tabAlpha << 24) | tabRgb);
        context.method_25300(this.field_22793, "Main", previewLeft + 4 + tabW / 2, previewTop + 8, 0xFFFFFFFF);

        context.method_25294(previewLeft + 8 + tabW, previewTop + 3, previewLeft + 8 + 2 * tabW, previewTop + barH - 3, (tabAlpha << 24) | tabRgb);
        context.method_25300(this.field_22793, "Player", previewLeft + 8 + tabW + tabW / 2, previewTop + 8, 0xFFFFFFFF);

        context.method_51433(this.field_22793, "Preview", previewRight - 40, previewTop + 8, 0xFFAAAAAA, false);

        int centerX = this.field_22789 / 2;
        int y = 36 + PREVIEW_HEIGHT + 8;
        context.method_25300(this.field_22793, "— HUD Size —", centerX, y - 12, 0xFF88CCFF);
        y += 2 * ROW_HEIGHT + 4 + ROW_HEIGHT + 6;
        context.method_25300(this.field_22793, "— Appearance —", centerX, y - 12, 0xFF88CCFF);
        y += 2 * ROW_HEIGHT + 4 + 2 * ROW_HEIGHT + 6;
        context.method_25300(this.field_22793, "— Private Messages —", centerX, y - 12, 0xFF88CCFF);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
