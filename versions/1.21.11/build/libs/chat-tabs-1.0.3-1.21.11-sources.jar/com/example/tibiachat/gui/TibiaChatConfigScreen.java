package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.SentMessageHistory;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TibiaChatConfigScreen extends class_437 {

    private static final int ROW = 20;
    private static final int SLIDER_W = 140;
    private static final int FIELD_W = 40;
    private static final int GAP = 4;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;
    private class_4185 themeButton;

    public TibiaChatConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Chat Tabs Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int left = cx - 160;
        int right = cx + 20;
        int y = 28;

        y = addSlider(left, y, "Tab bar size", TibiaChatConfig.MIN_BAR_SCALE, TibiaChatConfig.MAX_BAR_SCALE,
                config.tabBarScale(), false, "%.2fx", v -> config.setTabBarScale((float) v));
        y = addSlider(left, y, "Icon size", TibiaChatConfig.MIN_ICON_SCALE, TibiaChatConfig.MAX_ICON_SCALE,
                config.notifIconScale(), false, "%.2fx", v -> config.setNotifIconScale((float) v));

        int y2 = 28;
        y2 = addSlider(right, y2, "Bar opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabBarAlpha(), true, "%.0f", v -> config.setTabBarAlpha((int) v));
        y2 = addSlider(right, y2, "Tab opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabAlpha(), true, "%.0f", v -> config.setTabAlpha((int) v));

        y = Math.max(y, y2) + 6;

        themeButton = class_4185.method_46430(themeLabel(), btn -> {
            config.cycleColorTheme();
            config.save();
            btn.method_25355(themeLabel());
        }).method_46434(cx - 110, y, 220, 18).method_46431();
        this.method_37063(themeButton);
        y += ROW + 4;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reposition / Resize HUD"),
                btn -> { if (this.field_22787 != null) this.field_22787.method_1507(new HudEditScreen(this)); })
                .method_46434(cx - 110, y, 220, 18).method_46431());
        y += ROW + 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Message Detection"),
                btn -> { if (this.field_22787 != null) this.field_22787.method_1507(new ChatRegexConfigScreen(this)); })
                .method_46434(cx - 110, y, 220, 18).method_46431());
        y += ROW + 4;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Persist sent messages: " + (config.persistSentMessages() ? "ON" : "OFF")),
                btn -> {
                    config.setPersistSentMessages(!config.persistSentMessages());
                    config.save();
                    if (config.persistSentMessages()) {
                        SentMessageHistory.applyToChat();
                    }
                    this.method_41843();
                }).method_46434(cx - 110, y, 220, 18).method_46431());
        y += ROW + 2;

        y = addSlider(cx - 110, y, "Sent history size",
                TibiaChatConfig.MIN_SENT_HISTORY, TibiaChatConfig.MAX_SENT_HISTORY,
                config.sentMessageHistoryLimit(), true, "%.0f",
                v -> {
                    config.setSentMessageHistoryLimit((int) v);
                    SentMessageHistory.onLimitChanged();
                });
        y += 6;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Defaults"), btn -> {
            config.resetAllDefaults();
            config.save();
            SentMessageHistory.onLimitChanged();
            this.method_41843();
        }).method_46434(cx - 100, y, 200, 18).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(cx - 100, this.field_22790 - 26, 200, 18).method_46431());
    }

    private class_2561 themeLabel() {
        return class_2561.method_43470("Theme: " + config.colorTheme() + "  (click to cycle)");
    }

    private int addSlider(int x, int y, String label, double min, double max, double initial,
                          boolean whole, String fmt, DoubleConsumer apply) {
        ValueSlider slider = new ValueSlider(x, y, SLIDER_W, 16, min, max, initial, whole,
                v -> class_2561.method_43470(label + ": " + String.format(Locale.ROOT, fmt, v)),
                v -> { apply.accept(v); config.save(); });
        class_342 field = new class_342(this.field_22793, x + SLIDER_W + GAP, y, FIELD_W, 16, class_2561.method_43470(label));
        field.method_1852(String.format(Locale.ROOT, whole ? "%.0f" : "%.2f", initial));
        field.method_1863(text -> {
            try {
                double parsed = Double.parseDouble(text.trim());
                double clamped = Math.max(min, Math.min(max, parsed));
                slider.setRealValueSilently(clamped);
                apply.accept(clamped);
                config.save();
            } catch (NumberFormatException ignored) {}
        });
        this.method_37063(slider);
        this.method_37063(field);
        return y + ROW;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) this.field_22787.method_1507(parent);
    }
}
