package com.example.tibiachat.chat;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import com.mojang.authlib.GameProfile;
import java.time.*;
import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_338;

public final class ChatManager {
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;
    private final MessageClassifier classifier = new MessageClassifier(config);
    private final ConversationManager conversations = new ConversationManager();
    private final List<ChatMessage> main = new ArrayList<>();
    private final Deque<PendingEcho> pendingEchoes = new ArrayDeque<>();
    private String selectedKey = ConversationManager.MAIN;

    public List<ChatMessage> main() {
        return Collections.unmodifiableList(main);
    }

    public ConversationManager conversations() {
        return conversations;
    }

    public String selectedKey() {
        return selectedKey;
    }

    public void select(String key) {
        selectedKey = key;
        Conversation c = conversations.getByKey(key);
        if (c != null) c.clearUnread();
    }

    public List<ChatMessage> selectedMessages() {
        if (ConversationManager.MAIN.equals(selectedKey)) return main;
        Conversation c = conversations.getByKey(selectedKey);
        return c == null ? List.of() : c.messages();
    }

    public Conversation selectedConversation() {
        return conversations.getByKey(selectedKey);
    }

    public int totalUnread() {
        int total = 0;
        for (Conversation c : conversations.all()) total += c.unread();
        return total;
    }

    public String classifyAndStore(class_2561 message, GameProfile sender, Instant timestamp) {
        String raw = ComponentJson.detectionText(message);
        Classification cl = classifier.incoming(message, sender);

        if (cl.type() == MessageType.WHISPER_OUTGOING) {
            String fp = fingerprint(cl.playerName(), cl.body());
            removeMatchingPendingBody(raw);
            removeMatchingPending(fp);

            ChatMessage cm = make(
                message,
                MessageType.WHISPER_OUTGOING,
                cl.playerName(),
                cl.playerUuid(),
                null,
                timestamp,
                fp
            );

            main.add(cm);
            trimMain();
            ChatPersistence.scheduleSave();
            return ConversationManager.MAIN;
        }

        if (cl.type() == MessageType.WHISPER_INCOMING) {
            String fp = fingerprint(cl.playerName(), cl.body());
            if (removeMatchingPending(fp)) return null;

            Conversation c = conversations.getOrCreate(cl.playerName(), cl.playerUuid());
            ChatMessage cm = make(
                message,
                MessageType.WHISPER_INCOMING,
                cl.playerName(),
                cl.playerUuid(),
                c.key(),
                timestamp,
                fp
            );

            c.add(cm);
            c.trimTo(config.chatHistoryLimit());
            main.add(cm);
            trimMain();
            ChatPersistence.scheduleSave();

            if (!c.key().equals(selectedKey)) {
                c.markUnread();
            }

            return c.key();
        }

        ChatMessage cm = make(
            message,
            cl.type(),
            cl.playerName(),
            cl.playerUuid(),
            null,
            timestamp,
            fingerprint(cl.playerName(), raw)
        );

        main.add(cm);
        trimMain();
        ChatPersistence.scheduleSave();
        return ConversationManager.MAIN;
    }

    public void onOutgoingCommand(String command) {
        classifier.outgoingCommand(command).ifPresent(out -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null) return;

            Conversation c = conversations.getOrCreate(
                out.playerName(),
                findUuid(out.playerName())
            );

            String fp = fingerprint(out.playerName(), out.body());

            class_2561 rendered = class_2561.method_43470("You: ")
                .method_10852(class_2561.method_43470(out.body()));

            ChatMessage cm = make(
                rendered,
                MessageType.WHISPER_OUTGOING,
                mc.field_1724.method_5477().getString(),
                mc.field_1724.method_5667(),
                c.key(),
                Instant.now(),
                fp
            );

            c.add(cm);
            c.trimTo(config.chatHistoryLimit());
            pendingEchoes.addLast(new PendingEcho(fp, System.nanoTime()));
            ChatPersistence.scheduleSave();

            if (c.key().equals(selectedKey)) {
                addToHud(cm.component());
            }
        });
    }

    private void addToHud(class_2561 component) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1705 == null) return;
        class_338 chat = mc.field_1705.method_1743();
        if (chat != null) chat.method_1812(component);
    }

    public void refreshHud() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1705 == null) return;
        class_338 chat = mc.field_1705.method_1743();
        if (chat == null) return;
        chat.method_1808(false);
        List<ChatMessage> msgs = selectedMessages();
        int limit = config.chatHistoryLimit();
        int start = Math.max(0, msgs.size() - limit);
        for (int i = start; i < msgs.size(); i++) {
            chat.method_1812(msgs.get(i).component());
        }
    }

    public void trimMain() {
        int limit = config.chatHistoryLimit();
        int excess = main.size() - limit;
        if (excess > 0) {
            main.subList(0, excess).clear();
        }
    }

    public void replaceMain(List<ChatMessage> messages) {
        main.clear();
        if (messages != null) main.addAll(messages);
        trimMain();
    }

    public void restoreState(List<ChatMessage> mainMessages, List<Conversation> restored, String selected) {
        main.clear();
        conversations.clear();
        if (mainMessages != null) main.addAll(mainMessages);
        trimMain();
        if (restored != null) {
            for (Conversation c : restored) {
                c.trimTo(config.chatHistoryLimit());
                conversations.put(c);
            }
        }
        if (selected != null && !selected.isBlank()) {
            if (ConversationManager.MAIN.equals(selected) || conversations.getByKey(selected) != null) {
                selectedKey = selected;
            } else {
                selectedKey = ConversationManager.MAIN;
            }
        } else {
            selectedKey = ConversationManager.MAIN;
        }
    }

    private UUID findUuid(String name) {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 != null && mc.field_1724.method_5477().getString().equalsIgnoreCase(name)) {
            return mc.field_1724.method_5667();
        }

        if (mc.method_1562() != null) {
            var p = mc.method_1562().method_2874(name);
            if (p != null) return p.method_2966().id();
        }

        return null;
    }

    private ChatMessage make(
        class_2561 text,
        MessageType type,
        String name,
        UUID uuid,
        String key,
        Instant at,
        String fp
    ) {
        return new ChatMessage(text, type, name, uuid, key, at, fp);
    }

    private String fingerprint(String name, String body) {
        return (name == null ? "" : name.toLowerCase(Locale.ROOT)) + "|" + body.trim();
    }

    private static final long PENDING_ECHO_TTL_NS = 5_000_000_000L;

    private void expirePendingEchoes(long now) {
        while (!pendingEchoes.isEmpty()
                && now - pendingEchoes.peekFirst().nanoTime() > PENDING_ECHO_TTL_NS) {
            pendingEchoes.removeFirst();
        }
    }

    private boolean removeMatchingPendingBody(String raw) {
        long now = System.nanoTime();
        expirePendingEchoes(now);

        var it = pendingEchoes.iterator();
        while (it.hasNext()) {
            PendingEcho p = it.next();
            int sep = p.fingerprint().indexOf('|');
            String body = sep >= 0 ? p.fingerprint().substring(sep + 1) : "";
            if (!body.isBlank() && raw.contains(body)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    private boolean removeMatchingPending(String fp) {
        long now = System.nanoTime();
        expirePendingEchoes(now);

        var it = pendingEchoes.iterator();
        while (it.hasNext()) {
            PendingEcho p = it.next();
            if (p.fingerprint().equals(fp)) {
                it.remove();
                return true;
            }
        }
        return false;
    }

    public void tick() {
        ChatPersistence.tick();
    }

    private record PendingEcho(String fingerprint, long nanoTime) {}
}
