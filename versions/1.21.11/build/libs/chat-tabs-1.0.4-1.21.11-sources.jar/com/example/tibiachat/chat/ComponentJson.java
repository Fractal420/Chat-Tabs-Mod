package com.example.tibiachat.chat;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.util.regex.Pattern;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_8824;

public final class ComponentJson {
    private static final Gson GSON = new Gson();
    private static final Pattern HEAD_PLACEHOLDER = Pattern.compile(
            "\\[\\s*(?:unknown\\s+)?(?:player\\s+)?head\\s*\\]|\\[\\s*head\\s*\\]",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern MULTI_SPACE = Pattern.compile("[ \\t\\xA0]{2,}");

    private ComponentJson() {}

    public static class_7225.class_7874 registries() {
        class_310 mc = class_310.method_1551();
        if (mc != null) {
            if (mc.field_1687 != null) return mc.field_1687.method_30349();
            if (mc.field_1724 != null) return mc.field_1724.method_56673();
            if (mc.method_1562() != null) {
                try {
                    return mc.method_1562().method_29091();
                } catch (Exception ignored) {}
            }
        }
        return class_5455.field_40585;
    }

    private static DynamicOps<JsonElement> ops() {
        try {
            return registries().method_57093(JsonOps.INSTANCE);
        } catch (Exception ignored) {
            return JsonOps.INSTANCE;
        }
    }

    public static JsonElement toJson(class_2561 component) {
        if (component == null) return null;
        try {
            return class_8824.field_46597
                    .encodeStart(ops(), component)
                    .result()
                    .orElse(null);
        } catch (Exception ignored) {}
        try {
            JsonObject fallback = new JsonObject();
            fallback.addProperty("text", component.getString());
            return fallback;
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String toJsonString(class_2561 component) {
        JsonElement el = toJson(component);
        return el == null ? null : GSON.toJson(el);
    }

    public static class_2561 fromJson(JsonElement element) {
        return fromJson(element, null);
    }

    public static class_2561 fromJson(JsonElement element, String fallbackText) {
        if (element != null && !element.isJsonNull()) {
            try {
                class_2561 parsed = class_8824.field_46597
                        .parse(ops(), element)
                        .result()
                        .orElse(null);
                if (parsed != null) return parsed;
            } catch (Exception ignored) {}
            try {
                class_2561 parsed = class_8824.field_46597
                        .parse(JsonOps.INSTANCE, element)
                        .result()
                        .orElse(null);
                if (parsed != null) return parsed;
            } catch (Exception ignored) {}
        }
        return class_2561.method_43470(fallbackText == null ? "" : fallbackText);
    }

    public static class_2561 fromJsonString(String json) {
        if (json == null || json.isBlank()) return class_2561.method_43473();
        try {
            return fromJson(JsonParser.parseString(json));
        } catch (Exception ignored) {
            return class_2561.method_43470(json);
        }
    }

    public static String plainText(class_2561 component) {
        if (component == null) return "";
        try {
            return component.getString();
        } catch (Exception ignored) {
            return "";
        }
    }

    public static String detectionText(class_2561 component) {
        return normalizeForDetection(plainText(component));
    }

    public static String normalizeForDetection(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        String text = HEAD_PLACEHOLDER.matcher(raw).replaceAll("");
        text = text.replace('\u00A0', ' ');
        text = text.replace("\u200B", "");
        text = text.replace("\u200C", "");
        text = text.replace("\u200D", "");
        text = text.replace("\uFEFF", "");
        text = MULTI_SPACE.matcher(text).replaceAll(" ");
        return text.trim();
    }
}
