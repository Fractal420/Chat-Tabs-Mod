package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.Locale;
import java.util.function.IntConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ChatAppearanceConfigScreen extends class_437 {

    private static final int ROW_HEIGHT = 24;
    private static final int SLIDER_WIDTH = 200;
    private static final int FIELD_WIDTH = 50;
    private static final int FIELD_GAP = 6;
    private static final int LABEL_WIDTH = 170;
    private static final int HEX_FIELD_WIDTH = 90;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;

    public ChatAppearanceConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Tab Colors / Transparency"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        hexLabels.clear();

        int centerX = this.field_22789 / 2;
        int y = 40;

        y = addSliderRow(centerX, y, "Tab bar transparency", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabBarAlpha(), true, "%.0f",
                v -> config.setTabBarAlpha((int) v));

        y = addSliderRow(centerX, y, "Tab transparency", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabAlpha(), true, "%.0f",
                v -> config.setTabAlpha((int) v));

        y += 6;

        y = addHexColorRow(centerX, y, "Tab bar color (hex RRGGBB)", config.tabBarColor(),
                v -> config.setTabBarColor(v));

        y = addHexColorRow(centerX, y, "Tab color (hex RRGGBB)", config.tabColor(),
                v -> config.setTabColor(v));

        y += 12;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Colors to Defaults"), btn -> {
                    config.resetAppearanceDefaults();
                    config.save();
                    this.method_41843();
                })
                .method_46434(centerX - 100, y, 200, 20)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(centerX - 100, this.field_22790 - 28, 200, 20)
                .method_46431());
    }

    private int addSliderRow(int centerX, int y, String label, double min, double max, double initial,
                              boolean wholeNumber, String format, java.util.function.DoubleConsumer apply) {
        int sliderX = centerX - (SLIDER_WIDTH + FIELD_GAP + FIELD_WIDTH) / 2;
        int fieldX = sliderX + SLIDER_WIDTH + FIELD_GAP;

        ValueSlider slider = new ValueSlider(sliderX, y, SLIDER_WIDTH, 20, min, max, initial, wholeNumber,
                v -> class_2561.method_43470(label + ": " + String.format(Locale.ROOT, format, v)),
                v -> {
                    apply.accept(v);
                    config.save();
                });

        class_342 field = new class_342(this.field_22793, fieldX, y, FIELD_WIDTH, 20, class_2561.method_43470(label));
        field.method_1852(String.format(Locale.ROOT, wholeNumber ? "%.0f" : "%.2f", initial));
        field.method_1863(text -> {
            try {
                double parsed = Double.parseDouble(text.trim());
                double clamped = Math.max(min, Math.min(max, parsed));
                slider.setRealValueSilently(clamped);
                apply.accept(clamped);
                config.save();
            } catch (NumberFormatException ignored) {}
        });

        this.method_37063(slider);
        this.method_37063(field);
        return y + ROW_HEIGHT;
    }

    private int addHexColorRow(int centerX, int y, String label, int initialRgb, IntConsumer apply) {
        int totalWidth = LABEL_WIDTH + FIELD_GAP + HEX_FIELD_WIDTH;
        int labelX = centerX - totalWidth / 2;
        int fieldX = labelX + LABEL_WIDTH + FIELD_GAP;

        class_342 field = new class_342(this.field_22793, fieldX, y, HEX_FIELD_WIDTH, 20, class_2561.method_43470(label));
        field.method_1880(7);
        field.method_1852(String.format(Locale.ROOT, "%06X", initialRgb));
        field.method_1863(text -> {
            String hex = text.trim();
            if (hex.startsWith("#")) hex = hex.substring(1);
            if (!hex.matches("[0-9a-fA-F]{6}")) return;
            try {
                int parsed = Integer.parseInt(hex, 16);
                apply.accept(parsed);
                config.save();
            } catch (NumberFormatException ignored) {}
        });

        this.hexLabels.add(new HexLabel(label, labelX, y));
        this.method_37063(field);
        return y + ROW_HEIGHT;
    }

    private final java.util.List<HexLabel> hexLabels = new java.util.ArrayList<>();

    private record HexLabel(String text, int x, int y) {}

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFFFF);
        for (HexLabel h : hexLabels) {
            context.method_51433(this.field_22793, h.text(), h.x(), h.y() + 6, 0xFFFFFFFF, true);
        }
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
