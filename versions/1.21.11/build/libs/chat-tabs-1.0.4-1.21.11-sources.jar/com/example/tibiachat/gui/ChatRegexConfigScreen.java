package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ChatRegexConfigScreen extends class_437 {

    private static final int ROW = 20;
    private static final int GAP = 2;
    private static final int TOP = 28;
    private static final int BOTTOM_PAD = 52;
    private static final int REMOVE_W = 18;
    private static final int LEFT_LABEL_W = 110;
    private static final int LEFT_FIELD_W = 150;
    private static final int LEFT_COL_W = LEFT_LABEL_W + 8 + LEFT_FIELD_W;

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;

    private final List<String> workingFormats = new ArrayList<>();
    private int scrollIndex = 0;

    private class_342 whisperCommandBox;
    private class_342 aliasesBox;
    private class_342 playerNameBox;
    private int listTop;
    private int listBottom;
    private int leftX;
    private int rightX;
    private int rightW;

    public ChatRegexConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Message Detection"));
        this.parent = parent;
        this.workingFormats.addAll(config.whisperFormats());
    }

    private void cycleTimestampStyle() {
        List<String> styles = TibiaChatConfig.TIMESTAMP_STYLES;
        int idx = styles.indexOf(config.timestampStyle());
        if (idx < 0) idx = 0;
        config.setTimestampStyle(styles.get((idx + 1) % styles.size()));
        config.save();
        this.method_41843();
    }

    private void cycleHeadStyle() {
        List<String> styles = TibiaChatConfig.HEAD_STYLES;
        int idx = styles.indexOf(config.headStyle());
        if (idx < 0) idx = 0;
        config.setHeadStyle(styles.get((idx + 1) % styles.size()));
        config.save();
        this.method_41843();
    }

    @Override
    protected void method_25426() {
        int margin = 12;
        leftX = margin;
        int gapBetween = 16;
        rightX = leftX + LEFT_COL_W + gapBetween;
        rightW = Math.max(180, this.field_22789 - rightX - margin - REMOVE_W - 6);

        int y = TOP;
        int fieldX = leftX + LEFT_LABEL_W + 8;

        whisperCommandBox = new class_342(this.field_22793, fieldX, y, LEFT_FIELD_W, 18, class_2561.method_43470("cmd"));
        whisperCommandBox.method_1852(config.whisperCommand());
        whisperCommandBox.method_1863(text -> {
            if (!text.isBlank()) {
                config.setWhisperCommand(text.trim());
                config.save();
            }
        });
        this.method_37063(whisperCommandBox);
        y += ROW + GAP;

        aliasesBox = new class_342(this.field_22793, fieldX, y, LEFT_FIELD_W, 18, class_2561.method_43470("aliases"));
        aliasesBox.method_1852(String.join(", ", config.whisperAliases()));
        aliasesBox.method_1863(text -> {
            config.setWhisperAliases(List.of(text.split(",")));
            config.save();
        });
        this.method_37063(aliasesBox);
        y += ROW + GAP + 4;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Timestamps: " + (config.timestampsEnabled() ? "ON" : "OFF")),
                btn -> {
                    config.setTimestampsEnabled(!config.timestampsEnabled());
                    config.save();
                    this.method_41843();
                }).method_46434(leftX, y, LEFT_COL_W, 18).method_46431());
        y += ROW + GAP;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Format: " + config.timestampStyle()),
                btn -> cycleTimestampStyle()
        ).method_46434(leftX, y, LEFT_COL_W, 18).method_46431());
        y += ROW + GAP;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Heads: " + (config.headsEnabled() ? "ON" : "OFF")),
                btn -> {
                    config.setHeadsEnabled(!config.headsEnabled());
                    config.save();
                    this.method_41843();
                }).method_46434(leftX, y, LEFT_COL_W, 18).method_46431());
        y += ROW + GAP;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Head style: " + config.headStyle()),
                btn -> cycleHeadStyle()
        ).method_46434(leftX, y, LEFT_COL_W, 18).method_46431());
        y += ROW + GAP + 4;

        playerNameBox = new class_342(this.field_22793, fieldX, y, LEFT_FIELD_W, 18, class_2561.method_43470("name"));
        playerNameBox.method_1852(config.playerNamePattern());
        playerNameBox.method_1880(80);
        playerNameBox.method_1863(text -> {
            if (!text.isBlank()) {
                config.setPlayerNamePattern(text.trim());
                config.save();
            }
        });
        this.method_37063(playerNameBox);

        listTop = TOP;
        listBottom = this.field_22790 - BOTTOM_PAD;

        int visibleRows = Math.max(1, (listBottom - listTop) / (ROW + GAP));
        int maxScroll = Math.max(0, workingFormats.size() - visibleRows);
        scrollIndex = Math.max(0, Math.min(scrollIndex, maxScroll));

        int removeX = rightX + rightW + 4;
        int rowY = listTop;
        int last = Math.min(workingFormats.size(), scrollIndex + visibleRows);

        for (int i = scrollIndex; i < last; i++) {
            final int index = i;
            class_342 row = new class_342(this.field_22793, rightX, rowY, rightW, 18,
                    class_2561.method_43470("f" + (index + 1)));
            row.method_1880(200);
            row.method_1852(workingFormats.get(index));
            row.method_1863(text -> {
                if (index < workingFormats.size()) {
                    workingFormats.set(index, text);
                    applyFormats();
                }
            });
            this.method_37063(row);

            this.method_37063(class_4185.method_46430(class_2561.method_43470("x"), btn -> {
                        if (index < workingFormats.size()) {
                            workingFormats.remove(index);
                            applyFormats();
                            this.method_41843();
                        }
                    })
                    .method_46434(removeX, rowY, REMOVE_W, 18)
                    .method_46431());

            rowY += ROW + GAP;
        }

        int bottomY = this.field_22790 - BOTTOM_PAD + 10;
        int btnW = 120;
        int totalBtn = btnW * 3 + 16;
        int btnStart = Math.max(margin, (this.field_22789 - totalBtn) / 2);

        this.method_37063(class_4185.method_46430(class_2561.method_43470("+ Add Format"), btn -> {
                    workingFormats.add("{player} whispers: {message}");
                    applyFormats();
                    scrollIndex = Math.max(0, workingFormats.size() - visibleRows);
                    this.method_41843();
                })
                .method_46434(btnStart, bottomY, btnW, 18)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Defaults"), btn -> {
                    config.resetWhisperDetectionDefaults();
                    workingFormats.clear();
                    workingFormats.addAll(config.whisperFormats());
                    whisperCommandBox.method_1852(config.whisperCommand());
                    aliasesBox.method_1852(String.join(", ", config.whisperAliases()));
                    playerNameBox.method_1852(config.playerNamePattern());
                    scrollIndex = 0;
                    this.method_41843();
                })
                .method_46434(btnStart + btnW + 8, bottomY, btnW, 18)
                .method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(btnStart + (btnW + 8) * 2, bottomY, btnW, 18)
                .method_46431());
    }

    private void applyFormats() {
        config.setWhisperFormats(workingFormats.stream()
                .filter(s -> !s.isBlank())
                .collect(Collectors.toList()));
        config.save();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= rightX && mouseY >= listTop && mouseY < listBottom) {
            int visibleRows = Math.max(1, (listBottom - listTop) / (ROW + GAP));
            int maxScroll = Math.max(0, workingFormats.size() - visibleRows);
            int newScroll = Math.max(0, Math.min(maxScroll, scrollIndex - (int) Math.signum(verticalAmount)));
            if (newScroll != scrollIndex) {
                scrollIndex = newScroll;
                this.method_41843();
            }
            return true;
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);

        int y = TOP;
        context.method_51433(this.field_22793, "Whisper cmd:", leftX, y + 5, 0xFFFFFFFF, true);
        y += ROW + GAP;
        context.method_51433(this.field_22793, "Aliases:", leftX, y + 5, 0xFFFFFFFF, true);
        y += ROW + GAP + 4;
        y += (ROW + GAP) * 4;
        context.method_51433(this.field_22793, "Player name:", leftX, y + 5, 0xFFFFFFFF, true);

        context.method_51433(this.field_22793, "Formats  ({player}  {message})", rightX, listTop - 12, 0xFFAAAAAA, true);

        if (workingFormats.isEmpty()) {
            context.method_51433(this.field_22793, "No formats yet", rightX, listTop + 4, 0xFFAAAAAA, true);
        }
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
