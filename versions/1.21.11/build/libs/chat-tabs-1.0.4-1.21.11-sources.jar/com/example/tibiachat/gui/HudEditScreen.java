package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.config.TibiaChatConfig;
import com.example.tibiachat.hud.HudLayout;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HudEditScreen extends class_437 {

    private enum Target { NONE, TAB_BAR, TAB_BAR_RESIZE, ICON, SETTINGS_BTN }

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;
    private Target dragging = Target.NONE;
    private double dragStartMouseX;
    private double dragStartMouseY;
    private int dragStartOffsetX;
    private int dragStartOffsetY;
    private int dragStartWidth;

    public HudEditScreen(class_437 parent) {
        super(class_2561.method_43470("Reposition Chat Tabs HUD"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 28, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0x60000000);

        int barLeft = HudLayout.tabBarLeft();
        int barRight = HudLayout.tabBarRight(this.field_22789);
        int barTop = HudLayout.tabBarTop(this.field_22790);
        int barBottom = HudLayout.tabBarBottom(this.field_22790);

        int barAlpha = config.tabBarAlpha();
        int barRgb = config.tabBarColor();
        context.method_25294(barLeft, barTop, barRight, barBottom, (barAlpha << 24) | barRgb);
        context.method_25294(barRight - 6, barTop, barRight, barBottom, 0xFF4A90E2);

        int tabAlpha = config.tabAlpha();
        int tabRgb = config.tabColor();
        int mainW = Math.round(50 * HudLayout.tabTextScale());
        context.method_25294(barLeft + 2, barTop + 2, barLeft + 2 + mainW, barBottom - 2, (tabAlpha << 24) | tabRgb);
        context.method_25300(this.field_22793, "Main", barLeft + 2 + mainW / 2, barTop + (barBottom - barTop) / 2 - 4, 0xFFFFFFFF);

        int tabW = Math.round(70 * HudLayout.tabTextScale());
        context.method_25294(barLeft + 4 + mainW, barTop + 2, barLeft + 4 + mainW + tabW, barBottom - 2, (tabAlpha << 24) | tabRgb);
        context.method_25300(this.field_22793, "Sample", barLeft + 4 + mainW + tabW / 2, barTop + (barBottom - barTop) / 2 - 4, 0xFFFFFFFF);

        String sample = "\u2709 3";
        int textW = this.field_22793.method_1727(sample);
        int iconX = HudLayout.notifIconX();
        int iconY = HudLayout.notifIconY(this.field_22790);
        float iconScale = HudLayout.notifIconScale();
        int iconW = Math.max(Math.round((textW + 6) * iconScale), 20);
        int iconH = Math.max(Math.round(12 * iconScale), 14);
        context.method_25294(iconX - 3, iconY - 2, iconX + iconW, iconY + iconH, 0xB0C77A2A);
        context.method_51448().pushMatrix();
        context.method_51448().translate(iconX, iconY);
        context.method_51448().scale(iconScale, iconScale);
        context.method_51439(this.field_22793, class_2561.method_43470(sample), 0, 0, 0xFFFFD24A, true);
        context.method_51448().popMatrix();

        int sbX = HudLayout.settingsBtnX(this.field_22789);
        int sbY = HudLayout.settingsBtnY(this.field_22790);
        int sbW = HudLayout.settingsBtnW();
        int sbH = HudLayout.settingsBtnH();
        context.method_25294(sbX, sbY, sbX + sbW, sbY + sbH, 0xFF3A6EA5);
        context.method_51439(this.field_22793, class_2561.method_43470("\u2699"), sbX + 3, sbY + 3, 0xFFFFFFFF, true);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Drag tab bar / notif icon / settings button. Blue edge resizes tab bar."),
                this.field_22789 / 2, 12, 0xFFFFFFFF);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private boolean withinResizeHandle(double x, double y) {
        int top = HudLayout.tabBarTop(this.field_22790);
        int bottom = HudLayout.tabBarBottom(this.field_22790);
        int right = HudLayout.tabBarRight(this.field_22789);
        return x >= right - 8 && x <= right + 8 && y >= top && y < bottom;
    }

    private boolean withinTabBar(double x, double y) {
        int top = HudLayout.tabBarTop(this.field_22790);
        int bottom = HudLayout.tabBarBottom(this.field_22790);
        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(this.field_22789);
        return x >= left && x < right && y >= top && y < bottom;
    }

    private boolean withinIcon(double x, double y) {
        String sample = "\u2709 3";
        int textW = this.field_22793.method_1727(sample);
        int iconX = HudLayout.notifIconX();
        int iconY = HudLayout.notifIconY(this.field_22790);
        float iconScale = HudLayout.notifIconScale();
        int iconW = Math.max(Math.round((textW + 6) * iconScale), 20);
        int iconH = Math.max(Math.round(12 * iconScale), 14);
        return x >= iconX - 6 && x < iconX + iconW + 6 && y >= iconY - 6 && y < iconY + iconH + 6;
    }

    private boolean withinSettingsBtn(double x, double y) {
        int sbX = HudLayout.settingsBtnX(this.field_22789);
        int sbY = HudLayout.settingsBtnY(this.field_22790);
        int sbW = HudLayout.settingsBtnW();
        int sbH = HudLayout.settingsBtnH();
        return x >= sbX && x < sbX + sbW && y >= sbY && y < sbY + sbH;
    }

    private void beginDrag(Target target, double mouseX, double mouseY) {
        dragging = target;
        dragStartMouseX = mouseX;
        dragStartMouseY = mouseY;
        switch (target) {
            case TAB_BAR -> {
                dragStartOffsetX = config.tabBarOffsetX();
                dragStartOffsetY = config.tabBarOffsetY();
            }
            case TAB_BAR_RESIZE -> dragStartWidth = config.tabBarWidth();
            case ICON -> {
                dragStartOffsetX = config.notifIconOffsetX();
                dragStartOffsetY = config.notifIconOffsetY();
            }
            case SETTINGS_BTN -> {
                dragStartOffsetX = config.settingsBtnOffsetX();
                dragStartOffsetY = config.settingsBtnOffsetY();
            }
            default -> {}
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double x = click.comp_4798();
        double y = click.comp_4799();
        if (withinIcon(x, y)) {
            beginDrag(Target.ICON, x, y);
            return true;
        }
        if (withinSettingsBtn(x, y)) {
            beginDrag(Target.SETTINGS_BTN, x, y);
            return true;
        }
        if (withinResizeHandle(x, y)) {
            beginDrag(Target.TAB_BAR_RESIZE, x, y);
            return true;
        }
        if (withinTabBar(x, y)) {
            beginDrag(Target.TAB_BAR, x, y);
            return true;
        }
        dragging = Target.NONE;
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25403(class_11909 click, double offsetX, double offsetY) {
        if (dragging == Target.NONE) {
            return super.method_25403(click, offsetX, offsetY);
        }
        double dx = click.comp_4798() - dragStartMouseX;
        double dy = click.comp_4799() - dragStartMouseY;
        switch (dragging) {
            case TAB_BAR -> {
                config.setTabBarOffsetX((int) Math.round(dragStartOffsetX + dx));
                config.setTabBarOffsetY((int) Math.round(dragStartOffsetY + dy));
            }
            case TAB_BAR_RESIZE -> config.setTabBarWidth(Math.max(50, (int) Math.round(dragStartWidth + dx)));
            case ICON -> {
                config.setNotifIconOffsetX((int) Math.round(dragStartOffsetX + dx));
                config.setNotifIconOffsetY((int) Math.round(dragStartOffsetY + dy));
            }
            case SETTINGS_BTN -> {
                config.setSettingsBtnOffsetX((int) Math.round(dragStartOffsetX + dx));
                config.setSettingsBtnOffsetY((int) Math.round(dragStartOffsetY + dy));
            }
            default -> {}
        }
        return true;
    }

    @Override
    public boolean method_25406(class_11909 click) {
        boolean was = dragging != Target.NONE;
        dragging = Target.NONE;
        if (was) {
            config.save();
            return true;
        }
        return super.method_25406(click);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }
}
