package com.example.tibiachat.mixin;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.Conversation;
import com.example.tibiachat.chat.ConversationManager;
import com.example.tibiachat.hud.HudLayout;
import com.example.tibiachat.gui.TibiaChatConfigScreen;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public abstract class ChatScreenTabBarMixin {

    @Shadow
    protected class_342 input;

    private static final int TAB_W_MAIN_BASE = 50;
    private static final int TAB_W_MIN_BASE = 60;
    private static final int TAB_W_MAX_BASE = 120;
    private static final int TAB_SCROLL_STEP = 40;
    private static final int CLOSE_SIZE = 8;
    private static final int DRAG_THRESHOLD = 4;

    private int tibiaChatTabs$tabScroll = 0;

    private String tibiaChatTabs$dragKey = null;
    private boolean tibiaChatTabs$dragActive = false;
    private double tibiaChatTabs$dragPressX;
    private double tibiaChatTabs$dragPressY;
    private int tibiaChatTabs$dragPointerOffsetX;

    private int tibiaChatTabs$tabMainWidth() {
        return Math.round(TAB_W_MAIN_BASE * HudLayout.tabTextScale());
    }

    private int tibiaChatTabs$tabWidth(class_310 mc, String label) {
        float scale = HudLayout.tabTextScale();
        int baseW = mc.field_1772.method_1727(label) + 24;
        int clampedBase = Math.max(TAB_W_MIN_BASE, Math.min(TAB_W_MAX_BASE, baseW));
        return Math.round(clampedBase * scale);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void tibiaChatTabs$drawTabs(
            class_332 ctx,
            int mouseX,
            int mouseY,
            float delta,
            CallbackInfo ci
    ) {
        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(screenW);
        int top = HudLayout.tabBarTop(screenH);
        int bottom = HudLayout.tabBarBottom(screenH);

        tibiaChatTabs$tickDrag(mc, mouseX, mouseY, left, right, top, bottom);

        int barAlpha = TibiaChatTabsClient.CONFIG.tabBarAlpha();
        int barRgb = TibiaChatTabsClient.CONFIG.tabBarColor();
        ctx.method_25294(left, top, right, bottom, (barAlpha << 24) | barRgb);

        int mainW = tibiaChatTabs$tabMainWidth();
        int x = left + 2;

        x = tibiaChatTabs$drawTab(
                ctx,
                mc,
                "Main",
                ConversationManager.MAIN,
                x,
                mainW,
                top,
                bottom,
                mouseX,
                mouseY,
                0
        );

        int tabsLeft = x;
        int tabsRight = right - HudLayout.settingsBtnW() - 4;

        tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);

        int maxScroll = tibiaChatTabs$maxTabScroll(mc, tabsLeft, tabsRight);

        if (tabsRight > tabsLeft) {
            ctx.method_44379(tabsLeft, top, tabsRight, bottom);

            int tabX = tabsLeft - tibiaChatTabs$tabScroll;

            Conversation dragged = null;
            int draggedW = 0;

            for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
                int w = tibiaChatTabs$tabWidth(mc, c.playerName());

                boolean isDragged = tibiaChatTabs$dragActive && c.key().equals(tibiaChatTabs$dragKey);

                if (isDragged) {
                    dragged = c;
                    draggedW = w;
                } else if (tabX + w > tabsLeft && tabX < tabsRight) {
                    tibiaChatTabs$drawTab(
                            ctx,
                            mc,
                            c.playerName(),
                            c.key(),
                            tabX,
                            w,
                            top,
                            bottom,
                            mouseX,
                            mouseY,
                            c.unread()
                    );
                }

                tabX += w;
            }

            if (dragged != null) {
                int floatX = (int) Math.round(mouseX - tibiaChatTabs$dragPointerOffsetX);
                floatX = Math.max(tabsLeft, Math.min(tabsRight - draggedW, floatX));

                tibiaChatTabs$drawTab(
                        ctx,
                        mc,
                        dragged.playerName(),
                        dragged.key(),
                        floatX,
                        draggedW,
                        top,
                        bottom,
                        mouseX,
                        mouseY,
                        dragged.unread()
                );
            }

            ctx.method_44380();
        }

        if (tibiaChatTabs$tabScroll > 0) {
            ctx.method_25294(tabsLeft, top, tabsLeft + 8, bottom, 0xCC101010);
            ctx.method_51439(mc.field_1772, class_2561.method_43470("‹"), tabsLeft + 1, top + 3, 0xFFFFFFFF, true);
        }

        if (tibiaChatTabs$tabScroll < maxScroll) {
            ctx.method_25294(tabsRight - 8, top, tabsRight, bottom, 0xCC101010);
            ctx.method_51439(mc.field_1772, class_2561.method_43470("›"), tabsRight - 6, top + 3, 0xFFFFFFFF, true);
        }

        int sbX = HudLayout.settingsBtnX(screenW);
        int sbY = HudLayout.settingsBtnY(screenH);
        int sbW = HudLayout.settingsBtnW();
        int sbH = HudLayout.settingsBtnH();
        boolean sbHover = mouseX >= sbX && mouseX < sbX + sbW && mouseY >= sbY && mouseY < sbY + sbH;
        ctx.method_25294(sbX, sbY, sbX + sbW, sbY + sbH, sbHover ? 0xFF3A6EA5 : 0xCC202020);
        ctx.method_51439(mc.field_1772, class_2561.method_43470("⚙"), sbX + 3, sbY + 3, 0xFFFFFFFF, true);

        long remainingMs = TibiaChatTabsClient.CHAT.privateCooldownRemainingMs();
        if (TibiaChatTabsClient.CHAT.viewingPrivate() && remainingMs > 0) {
            double secs = remainingMs / 1000.0;
            String label = String.format(java.util.Locale.ROOT, "Cooldown: %.1fs", secs);
            int labelW = mc.field_1772.method_1727(label);
            int lx = 4;
            int ly = screenH - 28;
            ctx.method_25294(lx - 2, ly - 2, lx + labelW + 2, ly + 10, 0xC0000000);
            ctx.method_51439(mc.field_1772, class_2561.method_43470(label), lx, ly, 0xFFFF6B6B, true);
        }
    }

    private int tibiaChatTabs$totalTabsWidth(class_310 mc) {
        int width = 0;
        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            width += tibiaChatTabs$tabWidth(mc, c.playerName());
        }
        return width;
    }

    private int tibiaChatTabs$maxTabScroll(class_310 mc, int tabsLeft, int tabsRight) {
        int availableWidth = Math.max(0, tabsRight - tabsLeft);
        int totalWidth = tibiaChatTabs$totalTabsWidth(mc);
        return Math.max(0, totalWidth - availableWidth);
    }

    private void tibiaChatTabs$clampTabScroll(class_310 mc, int tabsLeft, int tabsRight) {
        int maxScroll = tibiaChatTabs$maxTabScroll(mc, tabsLeft, tabsRight);
        if (tibiaChatTabs$tabScroll < 0) {
            tibiaChatTabs$tabScroll = 0;
        }
        if (tibiaChatTabs$tabScroll > maxScroll) {
            tibiaChatTabs$tabScroll = maxScroll;
        }
    }

    private int tibiaChatTabs$drawTab(
            class_332 ctx,
            class_310 mc,
            String label,
            String key,
            int x,
            int w,
            int top,
            int bottom,
            int mouseX,
            int mouseY,
            int unread
    ) {
        boolean selected = TibiaChatTabsClient.CHAT.selectedKey().equals(key);
        boolean hover = mouseX >= x && mouseX < x + w && mouseY >= top && mouseY < bottom;

        int tabAlpha = TibiaChatTabsClient.CONFIG.tabAlpha();
        int tabRgb = TibiaChatTabsClient.CONFIG.tabColor();
        int shadedRgb = selected
                ? tibiaChatTabs$lighten(tabRgb, 0.18f)
                : (hover ? tibiaChatTabs$lighten(tabRgb, 0.09f) : tabRgb);

        ctx.method_25294(
                x,
                top,
                x + w - 1,
                bottom,
                (tabAlpha << 24) | shadedRgb
        );

        String shown = label;
        if (unread > 0) {
            shown = shown + " (" + unread + ")";
        }

        float textScale = HudLayout.tabTextScale();
        int closePadding = hover && !ConversationManager.MAIN.equals(key) ? Math.round((CLOSE_SIZE + 6) * textScale) : Math.round(5 * textScale);
        int maxTextWidth = w - closePadding - Math.round(4 * textScale);

        if (maxTextWidth > 0 && Math.round(mc.field_1772.method_1727(shown) * textScale) > maxTextWidth) {
            shown = mc.field_1772.method_27523(shown, Math.max(1, Math.round((maxTextWidth - Math.round(8 * textScale)) / textScale))) + "…";
        }

        ctx.method_51448().pushMatrix();
        ctx.method_51448().translate(x + Math.round(5 * textScale), top + 4);
        ctx.method_51448().scale(textScale, textScale);

        ctx.method_51439(
                mc.field_1772,
                class_2561.method_43470(shown),
                0,
                0,
                unread > 0 ? 0xFFFFD24A : 0xFFFFFFFF,
                true
        );

        ctx.method_51448().popMatrix();

        if (hover && !ConversationManager.MAIN.equals(key)) {
            int closeX = x + w - Math.round((CLOSE_SIZE + 2) * textScale);
            int closeY = top + 4;

            ctx.method_51439(
                    mc.field_1772,
                    class_2561.method_43470("×"),
                    closeX,
                    closeY - 1,
                    0xFFFFFFFF,
                    true
            );
        }

        return x + w;
    }

    private static int tibiaChatTabs$lighten(int rgb, float amount) {
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;
        r = Math.min(255, Math.round(r + (255 - r) * amount));
        g = Math.min(255, Math.round(g + (255 - g) * amount));
        b = Math.min(255, Math.round(b + (255 - b) * amount));
        return (r << 16) | (g << 8) | b;
    }

    private boolean tibiaChatTabs$isCloseHovered(
            double mouseX,
            double mouseY,
            int tabX,
            int tabW,
            int top,
            int bottom
    ) {
        float textScale = HudLayout.tabTextScale();
        int closeX = tabX + tabW - Math.round((CLOSE_SIZE + 2) * textScale);
        int closeY = top + 2;

        return mouseX >= closeX &&
                mouseX < closeX + Math.round(CLOSE_SIZE * textScale) &&
                mouseY >= closeY &&
                mouseY < bottom - 1;
    }

    @Inject(
            method = "mouseScrolled",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void tibiaChatTabs$onMouseScrolled(
            double mouseX,
            double mouseY,
            double horizontalAmount,
            double verticalAmount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(screenW);
        int top = HudLayout.tabBarTop(screenH);
        int bottom = HudLayout.tabBarBottom(screenH);

        double amount = Math.abs(horizontalAmount) > Math.abs(verticalAmount) ? horizontalAmount : verticalAmount;

        if (mouseX >= left && mouseX < right && mouseY >= top && mouseY < bottom) {
            int tabsLeft = left + 2 + tibiaChatTabs$tabMainWidth();
            int tabsRight = right - HudLayout.settingsBtnW() - 4;

            int maxScroll = tibiaChatTabs$maxTabScroll(mc, tabsLeft, tabsRight);
            if (maxScroll <= 0 || amount == 0) {
                return;
            }

            tibiaChatTabs$tabScroll -= (int) Math.round(amount * TAB_SCROLL_STEP);
            tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);

            cir.setReturnValue(true);
            return;
        }


    }

    @Inject(
            method = "mouseClicked",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void tibiaChatTabs$onClick(
            class_11909 click,
            boolean doubled,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return;
        }

        class_310 mc = class_310.method_1551();

        int screenW = mc.method_22683().method_4486();
        int screenH = mc.method_22683().method_4502();

        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(screenW);
        int top = HudLayout.tabBarTop(screenH);
        int bottom = HudLayout.tabBarBottom(screenH);

        int sbX = HudLayout.settingsBtnX(screenW);
        int sbY = HudLayout.settingsBtnY(screenH);
        int sbW = HudLayout.settingsBtnW();
        int sbH = HudLayout.settingsBtnH();
        if (click.comp_4798() >= sbX && click.comp_4798() < sbX + sbW && click.comp_4799() >= sbY && click.comp_4799() < sbY + sbH) {
            mc.method_1507(new TibiaChatConfigScreen((class_408) (Object) this));
            cir.setReturnValue(true);
            return;
        }

        if (click.comp_4798() < left || click.comp_4798() >= right || click.comp_4799() < top || click.comp_4799() >= bottom) {
            return;
        }

        int mainW = tibiaChatTabs$tabMainWidth();
        int x = left + 2;

        if (click.comp_4798() >= x && click.comp_4798() < x + mainW) {
            tibiaChatTabs$dragKey = null;
            tibiaChatTabs$dragActive = false;
            tibiaChatTabs$select(ConversationManager.MAIN);
            cir.setReturnValue(true);
            return;
        }

        int tabsLeft = x + mainW;
        int tabsRight = right - HudLayout.settingsBtnW() - 4;

        if (click.comp_4798() < tabsLeft || click.comp_4798() > tabsRight) {
            return;
        }

        tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);

        int tabX = tabsLeft - tibiaChatTabs$tabScroll;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = tibiaChatTabs$tabWidth(mc, c.playerName());

            if (tabX + w <= tabsLeft) {
                tabX += w;
                continue;
            }

            if (tabX >= tabsRight) {
                break;
            }

            if (click.comp_4798() >= tabX && click.comp_4798() < tabX + w) {
                if (tibiaChatTabs$isCloseHovered(click.comp_4798(), click.comp_4799(), tabX, w, top, bottom)) {
                    tibiaChatTabs$closeTab(c.key());
                } else {
                    tibiaChatTabs$dragKey = c.key();
                    tibiaChatTabs$dragActive = false;
                    tibiaChatTabs$dragPressX = click.comp_4798();
                    tibiaChatTabs$dragPressY = click.comp_4799();
                    tibiaChatTabs$dragPointerOffsetX = (int) Math.round(click.comp_4798() - tabX);
                    tibiaChatTabs$select(c.key());
                }
                cir.setReturnValue(true);
                return;
            }

            tabX += w;
        }
    }

    @Inject(
            method = "mouseReleased",
            at = @At("HEAD"),
            cancellable = true,
            require = 0
    )
    private void tibiaChatTabs$onMouseReleased(
            class_11909 click,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (tibiaChatTabs$dragKey == null) {
            return;
        }

        boolean wasDragging = tibiaChatTabs$dragActive;

        tibiaChatTabs$dragKey = null;
        tibiaChatTabs$dragActive = false;

        if (wasDragging) {
            cir.setReturnValue(true);
        }
    }

    private void tibiaChatTabs$tickDrag(
            class_310 mc,
            int mouseX,
            int mouseY,
            int left,
            int right,
            int top,
            int bottom
    ) {
        if (tibiaChatTabs$dragKey == null) {
            return;
        }

        long window = mc.method_22683().method_4490();
        boolean leftDown = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;

        if (!leftDown) {
            tibiaChatTabs$dragKey = null;
            tibiaChatTabs$dragActive = false;
            return;
        }

        if (!tibiaChatTabs$dragActive) {
            double dx = mouseX - tibiaChatTabs$dragPressX;
            double dy = mouseY - tibiaChatTabs$dragPressY;
            if (Math.abs(dx) < DRAG_THRESHOLD && Math.abs(dy) < DRAG_THRESHOLD) {
                return;
            }
            tibiaChatTabs$dragActive = true;
        }

        int tabsLeft = left + 2 + tibiaChatTabs$tabMainWidth();
        int tabsRight = right - HudLayout.settingsBtnW() - 4;

        double pointerX = Math.max(tabsLeft, Math.min(tabsRight, (double) mouseX));

        tibiaChatTabs$updateDragOrder(mc, tabsLeft, tabsRight, pointerX);
    }

    private void tibiaChatTabs$updateDragOrder(class_310 mc, int tabsLeft, int tabsRight, double pointerX) {
        ConversationManager conversations = TibiaChatTabsClient.CHAT.conversations();
        List<Conversation> order = conversations.asList();

        int currentIndex = -1;
        for (int i = 0; i < order.size(); i++) {
            if (order.get(i).key().equals(tibiaChatTabs$dragKey)) {
                currentIndex = i;
                break;
            }
        }

        if (currentIndex < 0) {
            return;
        }

        double x = tabsLeft - tibiaChatTabs$tabScroll;
        int targetIndex = currentIndex;

        for (int i = 0; i < order.size(); i++) {
            int w = tibiaChatTabs$tabWidth(mc, order.get(i).playerName());
            double mid = x + w / 2.0;

            if (i == currentIndex) {
                x += w;
                continue;
            }

            if (i < currentIndex) {
                if (pointerX < mid) {
                    targetIndex = Math.min(targetIndex, i);
                }
            } else {
                if (pointerX > mid) {
                    targetIndex = Math.max(targetIndex, i);
                }
            }

            x += w;
        }

        if (targetIndex != currentIndex) {
            conversations.moveToIndex(tibiaChatTabs$dragKey, targetIndex);
        }
    }

    private void tibiaChatTabs$closeTab(String key) {
        if (key.equals(tibiaChatTabs$dragKey)) {
            tibiaChatTabs$dragKey = null;
            tibiaChatTabs$dragActive = false;
        }

        String selectedKey = TibiaChatTabsClient.CHAT.selectedKey();
        boolean selected = key.equals(selectedKey);

        TibiaChatTabsClient.CHAT.conversations().remove(key);
        com.example.tibiachat.chat.ChatPersistence.scheduleSave();

        if (!selected) {
            tibiaChatTabs$clampTabScrollAfterClose();
            return;
        }

        tibiaChatTabs$select(ConversationManager.MAIN);
    }

    private void tibiaChatTabs$clampTabScrollAfterClose() {
        class_310 mc = class_310.method_1551();
        int screenW = mc.method_22683().method_4486();

        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(screenW);

        int tabsLeft = left + 2 + tibiaChatTabs$tabMainWidth();
        int tabsRight = right - HudLayout.settingsBtnW() - 4;

        tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);
    }



    private void tibiaChatTabs$select(String key) {
        if (TibiaChatTabsClient.CHAT.selectedKey().equals(key)) {
            return;
        }

        String previousKey = TibiaChatTabsClient.CHAT.selectedKey();
        TibiaChatTabsClient.CHAT.select(key);
        tibiaChatTabs$applyReplyPrefix(previousKey);
        tibiaChatTabs$scrollSelectedIntoView();
    }

    private void tibiaChatTabs$scrollSelectedIntoView() {
        class_310 mc = class_310.method_1551();
        int screenW = mc.method_22683().method_4486();

        int left = HudLayout.tabBarLeft();
        int right = HudLayout.tabBarRight(screenW);

        int tabsLeft = left + 2 + tibiaChatTabs$tabMainWidth();
        int tabsRight = right - HudLayout.settingsBtnW() - 4;

        String selectedKey = TibiaChatTabsClient.CHAT.selectedKey();

        if (ConversationManager.MAIN.equals(selectedKey)) {
            tibiaChatTabs$tabScroll = 0;
            return;
        }

        int tabX = tabsLeft;

        for (Conversation c : TibiaChatTabsClient.CHAT.conversations().all()) {
            int w = tibiaChatTabs$tabWidth(mc, c.playerName());

            if (c.key().equals(selectedKey)) {
                int visibleLeft = tabX - tibiaChatTabs$tabScroll;
                int visibleRight = visibleLeft + w;

                if (visibleLeft < tabsLeft) {
                    tibiaChatTabs$tabScroll -= tabsLeft - visibleLeft;
                } else if (visibleRight > tabsRight) {
                    tibiaChatTabs$tabScroll += visibleRight - tabsRight;
                }

                tibiaChatTabs$clampTabScroll(mc, tabsLeft, tabsRight);
                return;
            }

            tabX += w;
        }
    }

    private String tibiaChatTabs$replyPrefix(String playerName) {
        String cmd = TibiaChatTabsClient.CONFIG.whisperCommand();
        if (cmd == null || cmd.isBlank()) {
            cmd = "/w";
        }
        if (!cmd.startsWith("/")) {
            cmd = "/" + cmd;
        }
        return cmd + " " + playerName + " ";
    }

    private void tibiaChatTabs$applyReplyPrefix(String previousKey) {
        if (this.input == null) {
            return;
        }

        String key = TibiaChatTabsClient.CHAT.selectedKey();
        if (ConversationManager.MAIN.equals(key)) {
            if (previousKey != null && !ConversationManager.MAIN.equals(previousKey)) {
                Conversation prev = TibiaChatTabsClient.CHAT.conversations().getByKey(previousKey);
                if (prev != null) {
                    String prefix = tibiaChatTabs$replyPrefix(prev.playerName());
                    String current = this.input.method_1882();
                    if (current.startsWith(prefix) || current.equals(prefix.trim())) {
                        this.input.method_1852("");
                    }
                } else {
                    String current = this.input.method_1882();
                    String cmd = TibiaChatTabsClient.CONFIG.whisperCommand();
                    if (cmd == null || cmd.isBlank()) {
                        cmd = "/w";
                    }
                    if (!cmd.startsWith("/")) {
                        cmd = "/" + cmd;
                    }
                    if (current.startsWith(cmd + " ")) {
                        this.input.method_1852("");
                    }
                }
            }
            return;
        }

        Conversation c = TibiaChatTabsClient.CHAT.conversations().getByKey(key);
        if (c == null) {
            return;
        }

        String prefix = tibiaChatTabs$replyPrefix(c.playerName());
        String current = this.input.method_1882();
        if (!current.equals(prefix)) {
            this.input.method_1852(prefix);
            this.input.method_1875(prefix.length());
            this.input.method_1884(prefix.length());
        }
    }


    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true, require = 0)
    private void tibiaChatTabs$keepOpenOnPrivateEnter(net.minecraft.class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!TibiaChatTabsClient.CHAT.viewingPrivate()) {
            return;
        }
        int key = event.comp_4795();
        if (key != GLFW.GLFW_KEY_ENTER && key != GLFW.GLFW_KEY_KP_ENTER) {
            return;
        }
        if (this.input == null) {
            return;
        }
        Conversation c = TibiaChatTabsClient.CHAT.selectedConversation();
        String prefix = c != null ? tibiaChatTabs$replyPrefix(c.playerName()) : "";
        String value = this.input.method_1882();
        String trimmed = value == null ? "" : value.trim();
        boolean empty = trimmed.isEmpty() || trimmed.equals(prefix.trim());
        if (!empty) {
            if (TibiaChatTabsClient.CHAT.isPrivateCooldownActive()) {
                cir.setReturnValue(true);
                return;
            }
            class_408 self = (class_408) (Object) this;
            self.method_44056(value, true);
            TibiaChatTabsClient.CHAT.markPrivateSend();
        }
        if (c != null) {
            this.input.method_1852(prefix);
            this.input.method_1875(prefix.length());
            this.input.method_1884(prefix.length());
        } else {
            this.input.method_1852("");
        }
        cir.setReturnValue(true);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void tibiaChatTabs$onInit(CallbackInfo ci) {
        if (!ConversationManager.MAIN.equals(TibiaChatTabsClient.CHAT.selectedKey())) {
            TibiaChatTabsClient.CHAT.select(ConversationManager.MAIN);
        }
        tibiaChatTabs$applyReplyPrefix(null);
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void tibiaChatTabs$onRemoved(CallbackInfo ci) {
        if (this.input != null) {
            String current = this.input.method_1882();
            String cmd = TibiaChatTabsClient.CONFIG.whisperCommand();
            if (cmd == null || cmd.isBlank()) {
                cmd = "/w";
            }
            if (!cmd.startsWith("/")) {
                cmd = "/" + cmd;
            }
            if (current.startsWith(cmd + " ")) {
                this.input.method_1852("");
            }
        }
        TibiaChatTabsClient.CHAT.resetToMain();
    }
}
