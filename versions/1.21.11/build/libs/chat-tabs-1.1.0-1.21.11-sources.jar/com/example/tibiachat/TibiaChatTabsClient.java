package com.example.tibiachat;

import com.example.tibiachat.chat.ChatManager;
import com.example.tibiachat.chat.ChatPersistence;
import com.example.tibiachat.chat.SentMessageHistory;
import com.example.tibiachat.config.TibiaChatConfig;
import com.example.tibiachat.gui.TibiaChatConfigScreen;
import com.example.tibiachat.hud.HudLayout;
import com.example.tibiachat.hud.UnreadNotifier;
import com.example.tibiachat.chat.Conversation;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_9779;
import org.lwjgl.glfw.GLFW;

public final class TibiaChatTabsClient implements ClientModInitializer {
    public static final String MOD_ID = "tibia_chat_tabs";
    public static final TibiaChatConfig CONFIG = TibiaChatConfig.load();
    public static final ChatManager CHAT = new ChatManager();

    private static final class_304.class_11900 CHAT_TABS_CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "key_category"));

    private static class_304 openSettingsKey;

    @Override
    public void onInitializeClient() {
        openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.chat_tabs.open_settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_UNKNOWN,
                CHAT_TABS_CATEGORY
        ));

        ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, timestamp) -> {
            CHAT.observe(message, sender, timestamp);
            return true;
        });

        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!overlay) {
                CHAT.observe(message, null, java.time.Instant.now());
            }
            return true;
        });

        ClientSendMessageEvents.COMMAND.register(CHAT::onOutgoingCommand);

        SentMessageHistory.load();
        ChatPersistence.load();

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            SentMessageHistory.applyToChat();
            ChatPersistence.applyToHud();
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            client.execute(() -> {
                ChatPersistence.load();
                ChatPersistence.applyToHud();
                SentMessageHistory.applyToChat();
            });
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            CONFIG.save();
            SentMessageHistory.save();
            ChatPersistence.save();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            CHAT.tick();

            while (openSettingsKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new TibiaChatConfigScreen(null));
                }
            }
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CHAT,
                class_2960.method_60655(MOD_ID, "unread_badge"),
                this::renderUnreadBadge
        );
    }

    private void renderUnreadBadge(class_332 ctx, class_9779 tickCounter) {
        int unread = CHAT.totalUnread();
        UnreadNotifier.clearEntries();

        if (unread <= 0) {
            UnreadNotifier.collapse();
            return;
        }

        class_310 mc = class_310.method_1551();
        float scale = HudLayout.notifIconScale();
        int baseX = HudLayout.notifIconX();
        int baseY = HudLayout.notifIconY(mc.method_22683().method_4502());

        String badge = "\u2709 " + unread;
        int badgeW = mc.field_1772.method_1727(badge);
        int rowH = 12;

        UnreadNotifier.addEntry(
                "__badge__",
                baseX,
                baseY,
                baseX + Math.round((badgeW + 6) * scale),
                baseY + Math.round(rowH * scale)
        );

        if (UnreadNotifier.isExpanded()) {
            java.util.List<Conversation> list = UnreadNotifier.unreadConversations();
            int panelW = 0;
            for (Conversation c : list) {
                String line = c.playerName() + "  " + c.unread();
                panelW = Math.max(panelW, mc.field_1772.method_1727(line));
            }
            panelW = Math.max(panelW, badgeW) + 10;
            int panelH = list.size() * rowH + 4;
            int panelX = baseX;
            int panelY = baseY - Math.round((panelH + 2) * scale);

            ctx.method_51448().pushMatrix();
            ctx.method_51448().translate(panelX, panelY);
            ctx.method_51448().scale(scale, scale);
            ctx.method_25294(-2, -2, panelW + 2, panelH + 2, 0xE0101010);
            ctx.method_25294(-1, -1, panelW + 1, panelH + 1, 0xE0222222);

            int ly = 2;
            for (Conversation c : list) {
                String line = c.playerName() + "  " + c.unread();
                ctx.method_25294(0, ly - 1, panelW, ly + rowH - 2, 0x803A6EA5);
                ctx.method_51439(mc.field_1772, class_2561.method_43470(line), 4, ly, 0xFFFFD24A, true);
                int absY0 = panelY + Math.round(ly * scale);
                int absY1 = panelY + Math.round((ly + rowH) * scale);
                UnreadNotifier.addEntry(
                        c.key(),
                        panelX,
                        absY0,
                        panelX + Math.round(panelW * scale),
                        absY1
                );
                ly += rowH;
            }
            ctx.method_51448().popMatrix();
        }

        ctx.method_51448().pushMatrix();
        ctx.method_51448().translate(baseX, baseY);
        ctx.method_51448().scale(scale, scale);
        ctx.method_25294(-3, -2, badgeW + 3, 10, 0x90000000);
        ctx.method_51439(mc.field_1772, class_2561.method_43470(badge), 0, 0, 0xFFFFD24A, true);
        ctx.method_51448().popMatrix();
    }
}
