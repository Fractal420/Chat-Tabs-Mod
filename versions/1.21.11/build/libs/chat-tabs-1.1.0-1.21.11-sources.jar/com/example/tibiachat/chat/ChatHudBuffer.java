package com.example.tibiachat.chat;

import com.example.tibiachat.TibiaChatTabsClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_338;

public final class ChatHudBuffer {
    private static List<Object> mainAllSnapshot;
    private static List<Object> mainTrimmedSnapshot;
    private static final List<class_2561> pendingMain = new ArrayList<>();
    private static final Map<String, List<Object>> privateAll = new HashMap<>();
    private static final Map<String, List<Object>> privateTrimmed = new HashMap<>();

    private ChatHudBuffer() {}

    public static void snapshotMain() {
        class_338 chat = chat();
        if (chat == null) {
            mainAllSnapshot = null;
            mainTrimmedSnapshot = null;
            return;
        }
        Access access = (Access) chat;
        mainAllSnapshot = new ArrayList<>(access.tibiaChatTabs$allMessages());
        mainTrimmedSnapshot = new ArrayList<>(access.tibiaChatTabs$trimmedMessages());
        pendingMain.clear();
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void restoreMain() {
        class_338 chat = chat();
        if (chat == null) {
            return;
        }
        Access access = (Access) chat;
        TibiaChatTabsClient.CHAT.setWritingHud(true);
        try {
            if (mainAllSnapshot != null) {
                List all = access.tibiaChatTabs$allMessages();
                List trimmed = access.tibiaChatTabs$trimmedMessages();
                all.clear();
                all.addAll(mainAllSnapshot);
                trimmed.clear();
                if (mainTrimmedSnapshot != null) {
                    trimmed.addAll(mainTrimmedSnapshot);
                }
            } else {
                chat.method_1808(false);
            }
            for (class_2561 pending : pendingMain) {
                chat.method_1812(pending);
            }
            pendingMain.clear();
            mainAllSnapshot = null;
            mainTrimmedSnapshot = null;
        } finally {
            TibiaChatTabsClient.CHAT.setWritingHud(false);
        }
    }

    public static void queuePending(class_2561 message) {
        if (message != null) {
            pendingMain.add(message);
        }
    }

    public static boolean hasPrivateSnapshot(String key) {
        return key != null && privateAll.containsKey(key);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void restorePrivate(String key) {
        class_338 chat = chat();
        if (chat == null || key == null) {
            return;
        }
        List<Object> allSnap = privateAll.get(key);
        List<Object> trimmedSnap = privateTrimmed.get(key);
        if (allSnap == null) {
            return;
        }
        Access access = (Access) chat;
        TibiaChatTabsClient.CHAT.setWritingHud(true);
        try {
            List all = access.tibiaChatTabs$allMessages();
            List trimmed = access.tibiaChatTabs$trimmedMessages();
            all.clear();
            all.addAll(allSnap);
            trimmed.clear();
            if (trimmedSnap != null) {
                trimmed.addAll(trimmedSnap);
            }
        } finally {
            TibiaChatTabsClient.CHAT.setWritingHud(false);
        }
    }

    public static void capturePrivate(String key) {
        class_338 chat = chat();
        if (chat == null || key == null) {
            return;
        }
        Access access = (Access) chat;
        privateAll.put(key, new ArrayList<>(access.tibiaChatTabs$allMessages()));
        privateTrimmed.put(key, new ArrayList<>(access.tibiaChatTabs$trimmedMessages()));
    }

    public static void invalidatePrivate(String key) {
        if (key == null) {
            return;
        }
        privateAll.remove(key);
        privateTrimmed.remove(key);
    }

    private static class_338 chat() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1705 == null) {
            return null;
        }
        return mc.field_1705.method_1743();
    }

    public interface Access {
        List<?> tibiaChatTabs$allMessages();

        List<?> tibiaChatTabs$trimmedMessages();
    }
}
