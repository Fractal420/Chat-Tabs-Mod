package com.example.tibiachat.gui;

import com.example.tibiachat.TibiaChatTabsClient;
import com.example.tibiachat.chat.ChatPersistence;
import com.example.tibiachat.chat.NotificationSounds;
import com.example.tibiachat.chat.SentMessageHistory;
import com.example.tibiachat.config.TibiaChatConfig;
import java.util.Locale;
import java.util.function.DoubleConsumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TibiaChatConfigScreen extends class_437 {

    private static final int ROW = 26;
    private static final int SLIDER_H = 18;
    private static final int SLIDER_W = 120;
    private static final int FIELD_W = 40;
    private static final int FIELD_GAP = 6;
    private static final int HALF_W = 170;
    private static final int COL_GAP = 12;
    private static final int FULL_W = HALF_W * 2 + COL_GAP;
    private static final String[] TABS = {"Appearance", "Persistence", "Private"};

    private final class_437 parent;
    private final TibiaChatConfig config = TibiaChatTabsClient.CONFIG;
    private int activeTab;
    private class_4185 themeButton;


    public TibiaChatConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Chat Tabs Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int left = cx - FULL_W / 2;
        int right = left + HALF_W + COL_GAP;
        int tabY = 24;
        int tabW = FULL_W / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            final int tabIndex = i;
            boolean selected = i == activeTab;
            String label = (selected ? "> " : "") + TABS[i] + (selected ? " <" : "");
            this.method_37063(class_4185.method_46430(class_2561.method_43470(label), btn -> {
                activeTab = tabIndex;
                this.method_41843();
            }).method_46434(left + i * tabW, tabY, tabW - 2, 18).method_46431());
        }

        int y = tabY + 28;

        switch (activeTab) {
            case 0 -> buildAppearance(left, right, y);
            case 1 -> buildPersistence(left, right, y);
            case 2 -> buildPrivate(left, right, y);
            default -> {}
        }

        int footerY = this.field_22790 - 28;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Defaults"), btn -> {
            config.resetAllDefaults();
            config.save();
            SentMessageHistory.onLimitChanged();
            TibiaChatTabsClient.CHAT.trimMain();
            ChatPersistence.scheduleSave();
            this.method_41843();
        }).method_46434(left, footerY, HALF_W, 18).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(right, footerY, HALF_W, 18).method_46431());
    }

    private void buildAppearance(int left, int right, int y) {
        int yL = y;
        int yR = y;
        yL = addSlider(left, yL, "Tab bar size", TibiaChatConfig.MIN_BAR_SCALE, TibiaChatConfig.MAX_BAR_SCALE,
                config.tabBarScale(), false, "%.2fx", v -> config.setTabBarScale((float) v));
        yL = addSlider(left, yL, "Icon size", TibiaChatConfig.MIN_ICON_SCALE, TibiaChatConfig.MAX_ICON_SCALE,
                config.notifIconScale(), false, "%.2fx", v -> config.setNotifIconScale((float) v));
        yR = addSlider(right, yR, "Bar opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabBarAlpha(), true, "%.0f", v -> config.setTabBarAlpha((int) v));
        yR = addSlider(right, yR, "Tab opacity", TibiaChatConfig.MIN_ALPHA, TibiaChatConfig.MAX_ALPHA,
                config.tabAlpha(), true, "%.0f", v -> config.setTabAlpha((int) v));
        y = Math.max(yL, yR) + 6;

        themeButton = class_4185.method_46430(themeLabel(), btn -> {
            config.cycleColorTheme();
            config.save();
            btn.method_25355(themeLabel());
        }).method_46434(left, y, FULL_W, 18).method_46431();
        this.method_37063(themeButton);
        y += ROW + 4;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Reposition / Resize HUD"),
                btn -> openHudEdit())
                .method_46434(left, y, FULL_W, 18).method_46431());
        y += ROW + 4;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Message Detection"),
                btn -> openDetection())
                .method_46434(left, y, FULL_W, 18).method_46431());
    }

    private void buildPersistence(int left, int right, int y) {
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Sent history: " + onOff(config.persistSentMessages())),
                btn -> {
                    config.setPersistSentMessages(!config.persistSentMessages());
                    config.save();
                    if (config.persistSentMessages()) {
                        SentMessageHistory.applyToChat();
                    }
                    this.method_41843();
                }).method_46434(left, y, HALF_W, 18).method_46431());
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Chat log: " + onOff(config.persistChat())),
                btn -> {
                    config.setPersistChat(!config.persistChat());
                    config.save();
                    if (config.persistChat()) {
                        ChatPersistence.applyToHud();
                    }
                    this.method_41843();
                }).method_46434(right, y, HALF_W, 18).method_46431());
        y += ROW + 4;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Private tabs: " + onOff(config.persistTabs())),
                btn -> {
                    config.setPersistTabs(!config.persistTabs());
                    config.save();
                    this.method_41843();
                }).method_46434(left, y, FULL_W, 18).method_46431());
        y += ROW + 6;

        int yL = y;
        int yR = y;
        yL = addSlider(left, yL, "Sent limit",
                TibiaChatConfig.MIN_SENT_HISTORY, TibiaChatConfig.MAX_SENT_HISTORY,
                config.sentMessageHistoryLimit(), true, "%.0f",
                v -> {
                    config.setSentMessageHistoryLimit((int) v);
                    SentMessageHistory.onLimitChanged();
                });
        yR = addSlider(right, yR, "Chat limit",
                TibiaChatConfig.MIN_CHAT_HISTORY, TibiaChatConfig.MAX_CHAT_HISTORY,
                config.chatHistoryLimit(), true, "%.0f",
                v -> {
                    config.setChatHistoryLimit((int) v);
                    TibiaChatTabsClient.CHAT.trimMain();
                    ChatPersistence.scheduleSave();
                });
    }

    private void buildPrivate(int left, int right, int y) {
        y = addSlider(left, y, "Send cooldown",
                TibiaChatConfig.MIN_WHISPER_COOLDOWN, TibiaChatConfig.MAX_WHISPER_COOLDOWN,
                config.whisperCooldownSeconds(), true, "%.0fs",
                v -> config.setWhisperCooldownSeconds((int) v));
        y += 6;

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Sound: " + onOff(config.notifSoundEnabled())),
                btn -> {
                    config.setNotifSoundEnabled(!config.notifSoundEnabled());
                    config.save();
                    this.method_41843();
                }).method_46434(left, y, HALF_W, 18).method_46431());
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Tone: " + NotificationSounds.label(config.notifSoundIndex())),
                btn -> {
                    int next = NotificationSounds.nextIndex(config.notifSoundIndex());
                    config.setNotifSoundIndex(next);
                    config.save();
                    NotificationSounds.play(next, config.notifSoundVolume() / 100.0f);
                    this.method_41843();
                }).method_46434(right, y, HALF_W, 18).method_46431());
        y += ROW + 4;

        addSlider(left, y, "Sound volume",
                TibiaChatConfig.MIN_NOTIF_VOLUME, TibiaChatConfig.MAX_NOTIF_VOLUME,
                config.notifSoundVolume(), true, "%.0f%%",
                v -> config.setNotifSoundVolume((int) v));
    }





    private void openHudEdit() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(new HudEditScreen(this));
        }
    }

    private void openDetection() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(new ChatRegexConfigScreen(this));
        }
    }

    private static String onOff(boolean value) {
        return value ? "ON" : "OFF";
    }

    private class_2561 themeLabel() {
        return class_2561.method_43470("Theme: " + config.colorTheme() + "  (click to cycle)");
    }

    private int addSlider(int x, int y, String label, double min, double max, double initial,
                          boolean whole, String fmt, DoubleConsumer apply) {
        ValueSlider slider = new ValueSlider(x, y, SLIDER_W, SLIDER_H, min, max, initial, whole,
                v -> class_2561.method_43470(label + ": " + String.format(Locale.ROOT, fmt, v)),
                v -> { apply.accept(v); config.save(); });
        class_342 field = new class_342(this.field_22793, x + SLIDER_W + FIELD_GAP, y, FIELD_W, SLIDER_H, class_2561.method_43470(label));
        field.method_1852(String.format(Locale.ROOT, whole ? "%.0f" : "%.2f", initial));
        field.method_1863(text -> {
            try {
                double parsed = Double.parseDouble(text.trim());
                double clamped = Math.max(min, Math.min(max, parsed));
                slider.setRealValueSilently(clamped);
                apply.accept(clamped);
                config.save();
            } catch (NumberFormatException ignored) {}
        });
        this.method_37063(slider);
        this.method_37063(field);
        return y + ROW;
    }


    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 8, 0xFFFFFFFF);
    }

    @Override
    public void method_25419() {
        config.save();
        if (this.field_22787 != null) {
            this.field_22787.method_1507(parent);
        }
    }

}
